/*global history */
sap.ui.define([
	"hkmc/ca/zucaz00010/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("hkmc.ca.zucaa00020.controller.BaseController", {		
       
	});

});