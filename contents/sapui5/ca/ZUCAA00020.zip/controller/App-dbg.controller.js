sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("hkmc.ca.zucaa00020.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  