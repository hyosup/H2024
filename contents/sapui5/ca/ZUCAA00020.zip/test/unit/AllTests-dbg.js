sap.ui.define([
	"hkmcca/zucaa00020/test/unit/controller/List.controller"
], function () {
	"use strict";
});
