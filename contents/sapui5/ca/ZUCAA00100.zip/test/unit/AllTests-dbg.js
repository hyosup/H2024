sap.ui.define([
	"hkmcca/zucaa00100/test/unit/controller/List.controller"
], function () {
	"use strict";
});
