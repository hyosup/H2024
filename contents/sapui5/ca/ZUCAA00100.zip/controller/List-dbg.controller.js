sap.ui.define([
    "hkmc/ca/zucaa00100/controller/BaseController"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("hkmc.ca.zucaa00100.controller.List", {
            onInit: function () {
                this._getAuth();
                this.getRoute("RouteList").attachPatternMatched(this._onObjectListMatched, this);
            },
            _onObjectListMatched: function (oEvent) {
                this._oParameter = oEvent.getParameter("arguments");
            },
            onFilterInitialized: function (oEvt) {
                if (!this._oParameter["?param"]) {
                    return;
                }
                var oFilterBar = oEvt.getSource();

                oFilterBar.setFilterData({
                    DevType: {
                        "items": [{
                            key: this._oParameter["?param"].dev_type
                        }]
                    }
                });

                var oDevType = oFilterBar.getControlByKey("DevType");
                oDevType.attachSelectionChange(this.handleDevTypeChanged.bind(this));
                this._filterObjType();
            },
            handleDevTypeChanged: function (oEvt) {
                this._filterObjType();
            },
            _filterObjType: function () {
                var oFilterBar = this.byId("idSmartFilterBar"),
                    oDevType = oFilterBar.getControlByKey("DevType"),
                    oObjType = oFilterBar.getControlByKey("ObjType");

                var aFilter = [];
                oDevType.getSelectedKeys().forEach(function (sKey) {
                    aFilter.push(new sap.ui.model.Filter("code_grp", sap.ui.model.FilterOperator.EQ, sKey));
                });
                oObjType.getBinding("items").filter(aFilter);
            },
            onBeforeRebindTable: function (oEvt) {
                oEvt.getParameter("bindingParams").sorter.push(new sap.ui.model.Sorter("Erdat",true));
                oEvt.getParameter("bindingParams").sorter.push(new sap.ui.model.Sorter("Erzet",true));
            },
            handleItemPress: function (oEvent) {
                var oItem = oEvent.getSource();
                this.getRouter().navTo("RouteDetail", {
                    key: oItem.getSelectedItem().getBindingContext().getPath().substr(1)
                }, false);
            },
            handleCreate: function (oEvent) {
                this.getRouter().navTo("RouteCreate", null, false);
            }
        });
    });
