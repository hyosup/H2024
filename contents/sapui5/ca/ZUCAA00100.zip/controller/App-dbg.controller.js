sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("hkmc.ca.zucaa00100.controller.controller.App", {
        
      });
    }
  );
  