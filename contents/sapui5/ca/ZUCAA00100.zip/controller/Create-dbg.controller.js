sap.ui.define([
    "hkmc/ca/zucaa00100/controller/BaseController",
    "hkmc/ca/zucaa00100/model/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "hkmc/ca/zucaz00010/utils/Confirm",
    "hkmc/ca/zucaz00010/utils/UploadSet"
], function (
    Controller,
    formatter,
    JSONModel,
    MessageToast,
    Confirm,
    UploadSet
) {
    "use strict";

    return Controller.extend("hkmc.ca.zucaa00100.controller.Create", {
        formatter: formatter,
        _oUploadSet: null,
        onInit: function () {
            this._getAuth();
            this.getModel().attachRequestSent(function () {
                this.getView().setBusy(true);
            }.bind(this));
            this.getModel().attachRequestCompleted(function () {
                this.getView().setBusy(false);
            }.bind(this));
            this._sFileKey = "";
            this._aDeleteFiles = [];
            this.getRoute("RouteCreate").attachPatternMatched(this._onObjectMatched, this);
        },
        _onObjectMatched: function (oEvent) {
            var oModel = this.getView().getModel();
            if (oModel.hasPendingChanges()) {
                oModel.resetChanges();
                
            }
            this.byId("idLanguComboBox").setSelectedKey(sap.ui.getCore().getConfiguration().getLanguage().toUpperCase());
            this.setViewConfig("/isEdit", true);
            this.setViewConfig("/isCreate", true);
            this._sFileKey = "";
            this._aDeleteFiles = [];
            oModel.metadataLoaded().then(function () {
                var oContext = oModel.createEntry("ZVCAA00130C_DDL", {
                    properties: {
                        Fdate: new Date(),
                        Tdate: new Date("9999-12-31")
                    }
                });
                this.getView().setBindingContext(oContext);
            }.bind(this));

            this._oUploadSet = new UploadSet("", this.byId("idUploadSetContainer"), "{viewConfig>/isEdit}", {
                beforeUploadStarts: this.onBeforeUploadStarts.bind(this),
                uploadComplete: this.onUploadComplete.bind(this)
            });
            
            this._oUploadSet.filterItems(this._getAppID(), this._sFileKey);

            this._bindEditor("idRTEOverviewCreate");
            this._bindEditor("idRTEDetailCreate");
            this._bindEditor("idRTESampleCreate");
        },
        _bindEditor: function (sId) {
            var oContainer = this.getView().byId(sId + "Container");
            oContainer.destroyItems();
            this.setRichTextEditor(sId, oContainer, "", this.getViewConfig("/isEdit"), "{viewConfig>/isEdit}");
        },
        onDevTypeCreated: function (oEvt) {
            var oDevType = oEvt.getParameters()[0];
            if (oDevType.attachSelectionChange) {
                oDevType.attachSelectionChange(this.handleDevTypeChanged.bind(this));
            }
        },
        handleDevTypeChanged: function (oEvt) {
            var oDevType = oEvt.getSource(),
                oObjType = this.byId("idObjTypeCombobox").getInnerControls()[0];
            var aFilter = [];
            aFilter.push(new sap.ui.model.Filter("code_grp", sap.ui.model.FilterOperator.EQ, oDevType.getSelectedKey()));
            oObjType.getBinding("items").filter(aFilter);
        },
        _filterObjType: function () {
            var oFilterBar = this.byId("idSmartFilterBar"),
                oDevType = oFilterBar.getControlByKey("DevType"),
                oObjType = oFilterBar.getControlByKey("ObjType");

            var aFilter = [];
            oDevType.getSelectedKeys().forEach(function (sKey) {
                aFilter.push(new sap.ui.model.Filter("code_grp", sap.ui.model.FilterOperator.EQ, sKey));
            });
            oObjType.getBinding("items").filter(aFilter);
        },
        handleSave: function (oEvent) {
            this._submitSave(true, false);               
        },       
        handleSectionChagned: function (oEvt) {
            var oResourceBundle = this.getResourceBundle(),
                oModel = this.getViewModel(),
                sLangu = this.byId("idLanguComboBox").getSelectedKey(),
                oContext = this.getView().getBindingContext(),
                oEntity = oContext.getObject();
            var oSectionItem = this._getSectionItem();
            if (oSectionItem[0] === "ATTACHMENT") {
                return;
            }
            if (!oContext.bCreated) {
                var sPath = oModel.createKey("/ContentListSet", {
                    ObjId: oEntity.ObjId,
                    ContentType: oSectionItem[0],
                    Spras: sLangu
                });
                oModel.read(sPath, {
                    success: function (oData) {
                        oSectionItem[1].setValue(oData.Content);
                    },
                    error: function () {
                        oSectionItem[1].setValue("");
                    }
                });
            } else {
                oSectionItem[1].setValue("");
            }
        },
        handleLanguChange: function (oEvt) {
            var oResourceBundle = this.getResourceBundle(),
                oModel = this.getViewModel(),
                sLangu = oEvt.getParameter("selectedItem").getKey(),
                oContext = this.getView().getBindingContext(),
                oEntity = oContext.getObject();
            var oSectionItem = this._getSectionItem();
            if (oSectionItem[0] === "ATTACHMENT") {
                return;
            }
            if (!oContext.bCreated) {
                var sPath = oModel.createKey("/ContentListSet", {
                    ObjId: oEntity.ObjId,
                    ContentType: oSectionItem[0],
                    Spras: sLangu
                });
                oModel.read(sPath, {
                    success: function (oData) {
                        oSectionItem[1].setValue(oData.Content);
                    },
                    error: function () {
                        oSectionItem[1].setValue("");
                    }
                });
            } else {
                oSectionItem[1].setValue("");
            }
        }
    });
});
