sap.ui.define([
    "hkmc/ca/zucaa00100/controller/BaseController",
    "hkmc/ca/zucaa00100/model/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "hkmc/ca/zucaz00010/dialog/Confirm",
    "hkmc/ca/zucaz00010/utils/UploadSet"
], function (
    Controller, formatter, JSONModel, MessageToast, Confirm, UploadSet
) {
    "use strict";

    return Controller.extend("hkmc.ca.zucaa00100.controller.Detail", {
        formatter: formatter,
        _oUploadSet: null,
        onInit: function () {
            this._getAuth();
            this.getModel().attachRequestSent(function () {
                this.getView().setBusy(true);
            }.bind(this));
            this.getModel().attachRequestCompleted(function () {
                this.getView().setBusy(false);
            }.bind(this));
            this._aDeleteFiles = [];
            this.getRoute("RouteDetail").attachPatternMatched(this._onObjectMatched, this);
        },
        _onObjectMatched: function (oEvent) {
            this._sKey = "/" + oEvent.getParameter("arguments").key;
            this._sFileKey = "";
            var oModel = this.getView().getModel();
            if (oModel.hasPendingChanges()) {
                oModel.resetChanges();
            }
            this.setViewConfig("/isEdit", false);
            this.setViewConfig("/isCreate", false);
            this._aDeleteFiles = [];
            this.byId("idLanguComboBox").setSelectedKey(sap.ui.getCore().getConfiguration().getLanguage().toUpperCase());
            this.getView().bindElement({
                path: this._sKey,
                events: {
                    change: function (oEvt) {
                        var oData = oEvt.getSource().getBoundContext().getObject(),
                            sLangu = this.byId("idLanguComboBox").getSelectedKey();

                        this._sFileKey = oData.ObjId;
                        this._oUploadSet = new UploadSet("", this.byId("idUploadSetContainer"), "{viewConfig>/isEdit}", {
                            beforeUploadStarts: this.onBeforeUploadStarts.bind(this),
                            uploadComplete: this.onUploadComplete.bind(this),
                            removePressed: this.handleFileDelete.bind(this)
                        });
                        
                        this._oUploadSet.filterItems(this._getAppID(), this._sFileKey);

                        this._bindEditor("idRTEOverviewDetail", oData.ObjId, "OVERVIEW", sLangu);
                        this._bindEditor("idRTEDetailDetail", oData.ObjId, "DETAIL", sLangu);
                        this._bindEditor("idRTESampleDetail", oData.ObjId, "SAMPLE", sLangu);
                    }.bind(this)
                }
            });
        },

        _bindEditor: function (sId, sObjId, sContentType, sLangu) {
            var oContainer = this.getView().byId(sId + "Container"),
                oModel = this.getView().getModel();
            var sPath = oModel.createKey("/ContentListSet", {
                ObjId: sObjId,
                ContentType: sContentType,
                Spras: sLangu
            });

            oContainer.destroyItems();
            oModel.read(sPath, {
                success: function (oData) {
                    this.setRichTextEditor(sId, oContainer, oData.Content, this.getViewConfig("/isEdit"), "{viewConfig>/isEdit}");
                }.bind(this)
            });
        },
        handleEdit: function () {
            this.setViewConfig("/isEdit", !this.getViewConfig("/isEdit"));
            var oData = this.getView().getBindingContext().getObject(),
                sLangu = this.byId("idLanguComboBox").getSelectedKey(),
                oSectionItem = this._getSectionItem();
            if (oSectionItem[0] === "ATTACHMENT") {
                this._oUploadSet.filterItems(this._getAppID(), this._sFileKey);
            } else {
                this._bindEditor(oSectionItem[1].getId(), oData.ObjId, oSectionItem[0], sLangu);
            }            
        },
        handleSave: function (oEvent) {
            this._submitSave(true, false);
        },
        handleSectionChagned: function (oEvt) {
            var oData = this.getView().getBindingContext().getObject(),
                sLangu = this.byId("idLanguComboBox").getSelectedKey(),
                oSectionItem = this._getSectionItem();
            if (oSectionItem[0] === "ATTACHMENT") {
                this._oUploadSet.filterItems(this._getAppID(), this._sFileKey);
            } else {
                this._bindEditor(oSectionItem[1].getId(), oData.ObjId, oSectionItem[0], sLangu);
            }

        },
        handleLanguChange: function (oEvt) {
            var oData = this.getView().getBindingContext().getObject(),
                sLangu = oEvt.getParameter("selectedItem").getKey(),
                oSectionItem = this._getSectionItem();
            if (oSectionItem[0] === "ATTACHMENT") {
                return;
            }
            this._bindEditor(oSectionItem[1].getId(), oData.ObjId, oSectionItem[0], sLangu);
        },
        handleDelete: function () {
            var oConfirm = new Confirm({
                handleSubmit: this._confirmDelete.bind(this)
            });
            oConfirm.delete();
        },
        _confirmDelete: function () {
            var oModel = this.getViewModel(),
                oResourceBundle = this.getResourceBundle("i18n");

            oModel.remove(this._sKey, {
                success: function (oData, oResponse) {
                    this.setViewConfig("/isEdit", false);
                    MessageToast.show(oResourceBundle.getText("deleteSuccessfully"));

                    this.getView().unbindObject();
                    this.goNavBack();
                }.bind(this),
                error: function (oError) {
                    sap.m.MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                }
            });
        }
    });
});
