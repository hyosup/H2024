/*global history */
sap.ui.define([
    "hkmc/ca/zucaz00010/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "hkmc/ca/zucaz00010/utils/Auth",
    "sap/ui/core/routing/History",
    "sap/m/MessageToast",
    "hkmc/ca/zucaz00010/dialog/Confirm"
], function (Controller,
    JSONModel,
    Auth,
    History,
    MessageToast,
    Confirm) {
    "use strict";

    return Controller.extend("hkmc.ca.zucaa00100.controller.BaseController", {
        _getAppID: function () {
            return "ZUCAA00100";
        },
        _getAuth: function () {
            var that = this;
            var oAuth = new Auth(this._getAppID());
            if (!this.getViewModel("viewConfig")) {
                this.setViewModel(this.getModel("viewConfig"), "viewConfig");
            }
            that.getViewModel("viewConfig").setProperty("/isAuth", oAuth.getAuth());
        },
        handleToList: function (oEvent) {
            var oModel = this.getView().getModel();
            if (oModel.hasPendingChanges()) {
                oModel.resetChanges();
            }
            this.getView().unbindObject();
            this.getRouter().navTo("RouteList");
        },
        _getSectionItem: function () {
            var sSection = this.byId("idObjectPageLayout").getSelectedSection(),
                aSection = this.byId("idObjectPageLayout").getSections(),
                sContentType = "",
                oObject = null;
            for (var i = 0; i < aSection.length; i++) {
                if (aSection[i].getId() === sSection) {
                    if (i === 0) {
                        sContentType = "OVERVIEW";
                    } else if (i === 1) {
                        sContentType = "DETAIL";
                    } else if (i === 2) {
                        sContentType = "SAMPLE";
                    } else if (i === 3) {
                        sContentType = "ATTACHMENT";
                    }

                    oObject = aSection[i].getSubSections()[0].getBlocks()[0].getItems()[0];
                }
            }
            return [sContentType, oObject];
        },
        goNavBack: function (sName, oParameters, oComponentTargetInfo, bReplace) {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                if (sName) {
                    this.getRouter().navTo(sName, oParameters, oComponentTargetInfo, bReplace);
                } else {
                    this.getRouter().navTo("RouteList", oParameters, oComponentTargetInfo, bReplace);
                }

            }
        },

        handleFileSizeExceeded: function () {
            MessageToast.show("The file size is too large(Max 100MB)");
        },
        onBeforeUploadStarts: function (oEvt) {

            var sToken = this.getModel().getSecurityToken(),
                oUpload = oEvt.getSource(),
                oItem = oEvt.getParameter("item");
            oUpload.setBusy(true);

            oUpload.insertHeaderField(new sap.ui.core.Item({ key: "slug", text: encodeURIComponent(oItem.getFileName()) }), 1);
            oUpload.insertHeaderField(new sap.ui.core.Item({ key: "x-csrf-token", text: sToken }), 1);
            oUpload.insertHeaderField(new sap.ui.core.Item({ key: "appid", text: this._getAppID() }), 1);
            oUpload.insertHeaderField(new sap.ui.core.Item({ key: "cbokey", text: this._sFileKey }), 1);

        },
        onUploadComplete: function (oEvt) {
            oEvt.getSource().setBusy(false);
        },
        handleFileDelete: function (oEvt) {
            var oUpload = oEvt.getSource();
            this._aDeleteFiles.push(oUpload.getBindingContext("attachModel"));
        },
        _updateContent: function (oData) {
            var sSection = this.byId("idObjectPageLayout").getSelectedSection(),
                oResourceBundle = this.getResourceBundle(),
                oSectionItem = this._getSectionItem(),
                oModel = this.getViewModel(),
                sContentType = oSectionItem[0];
            this._sFileKey = oData.ObjId;

            if (sContentType === "ATTACHMENT") {

                this._oUploadSet.upload();

                this._aDeleteFiles.forEach(function (oContenxt) {
                    oModel.remove(oContenxt.getPath());
                }.bind(this));
                this._aDeleteFiles = [];
                MessageToast.show(oResourceBundle.getText("saveSuccessfully"));
            } else {
                var sContent = oSectionItem[1].getValue(),
                    sLangu = this.byId("idLanguComboBox").getSelectedKey();

                if (sContentType !== "") {
                    var sPath = oModel.createKey("/ContentListSet", {
                        ObjId: oData.ObjId,
                        ContentType: sContentType,
                        Spras: sLangu
                    });
                    oModel.update(sPath, {
                        ObjId: oData.ObjId,
                        ContentType: sContentType,
                        Spras: sLangu,
                        Content: sContent
                    }, {
                        success: function () {
                            MessageToast.show(oResourceBundle.getText("saveSuccessfully"));
                        }
                    });

                }
            }

        },
        _submitSave: function (bEdit, bCreate) {
            var oModel = this.getView().getModel(),
                oResourceBundle = this.getResourceBundle(),
                oSmartForm1 = this.byId("idSmartForm1"),
                oSmartForm2 = this.byId("idSmartForm2");

            if (oSmartForm1.check().length > 0) {
                sap.m.MessageBox.error(oResourceBundle.getText("checkMandatory"));
                return;
            }
            if (oSmartForm2.check().length > 0) {
                sap.m.MessageBox.error(oResourceBundle.getText("checkMandatory"));
                return;
            }

            if (oModel.hasPendingChanges()) {
                oModel.submitChanges({
                    success: function (oData) {
                        this.setViewConfig("/isEdit", bEdit);
                        this.setViewConfig("/isCreate", bCreate);
                        this._updateContent(this.getView().getBindingContext().getObject());
                    }.bind(this),
                    error: function (oError) {
                        if (oError.statusCode === 500) {
                            MessageToast.show(oResourceBundle.getText("MsgCreateError"));
                        } else {
                            MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                        }
                    }
                });
            } else {
                this._updateContent(this.getView().getBindingContext().getObject());
            }
        }
    });

});