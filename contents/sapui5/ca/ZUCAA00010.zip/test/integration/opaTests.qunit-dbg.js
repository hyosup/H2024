/* global QUnit */

sap.ui.require(["hkmc/ca/zucaa00010/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
