sap.ui.define([
	"hkmcca/zucaa00010/test/unit/controller/List.controller"
], function () {
	"use strict";
});
