/*global history */
sap.ui.define([
    "hkmc/ca/zucaz00010/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "hkmc/ca/zucaz00010/utils/Auth",
    "sap/ui/core/routing/History",
    "sap/m/MessageToast"
], function (Controller,
    JSONModel,
    Auth,
    History,
    MessageToast) {
    "use strict";

    return Controller.extend("hkmc.ca.zucaa00200.controller.BaseController", {
        _getAppID: function () {
            return "ZUCAA00100";
        },
        _getAuth: function () {
            var that = this;
            var oAuth = new Auth(this._getAppID());
            if (!this.getViewModel("viewConfig")) {
                this.setViewModel(this.getModel("viewConfig"), "viewConfig");
            }
            that.getViewModel("viewConfig").setProperty("/isAuth", oAuth.getAuth());
        },
        handleToList: function (oEvent) {
            var oModel = this.getView().getModel();
            if (oModel.hasPendingChanges()) {
                oModel.resetChanges();
            }
            this.getView().unbindObject();
            this.getRouter().navTo("RouteList");
        },
        
        goNavBack: function (sName, oParameters, oComponentTargetInfo, bReplace) {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                if (sName) {
                    this.getRouter().navTo(sName, oParameters, oComponentTargetInfo, bReplace);
                } else {
                    this.getRouter().navTo("RouteList", oParameters, oComponentTargetInfo, bReplace);
                }

            }
        }
      
    });

});