sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("hkmc.ca.zucaa00200.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  