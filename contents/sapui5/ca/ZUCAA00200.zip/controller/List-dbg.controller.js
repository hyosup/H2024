sap.ui.define([
    "hkmc/ca/zucaa00200/controller/BaseController",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel) {
        "use strict";

        return Controller.extend("hkmc.ca.zucaa00200.controller.List", {
            onInit: function () {
                this.getModel().read("/TreeSet('DUMMY')", {
                    success: function (oData, oResp) {
                        var oModel = new JSONModel(JSON.parse(oData.JsonData));

                        this.getView().setModel(oModel);
                    }.bind(this)
                });
                var oResourceBundle = this.getResourceBundle();
                this._graph = this.byId("graph");
                this._graph.setCustomLegendLabel({
                    label: oResourceBundle.getText("txtNodeLegend01"),
                    status: "Success"
                });
                this._graph.setCustomLegendLabel({
                    label: oResourceBundle.getText("txtNodeLegend02"),
                    status: "Information"
                });
                this._graph.setCustomLegendLabel({
                    label: oResourceBundle.getText("txtNodeLegend03"),
                    status: "Success",
                    isNode: false
                });
                this._graph.setCustomLegendLabel({
                    label: oResourceBundle.getText("txtNodeLegend04"),
                    status: "Error",
                    isNode: false
                });
            },
            handleNodePress: function (oEvt) {
                var oEntity = oEvt.getSource().getBindingContext().getObject();

                if (oEntity.nodeType === "leaf" && oEntity.objectId !== "") {
                    var sPath = "ZVCAA00130C_DDL('" + oEntity.objectId + "')";
                    this.getRouter().navTo("RouteDetail", { key: sPath }, false);
                }
                else {
                    this.setViewConfig("/layout", sap.f.LayoutType.OneColumn);
                }

            }
        });
    });
