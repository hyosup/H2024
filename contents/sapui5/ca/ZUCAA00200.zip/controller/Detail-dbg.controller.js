sap.ui.define([
	"hkmc/ca/zucaa00200/controller/BaseController"
], function(
	Controller
) {
	"use strict";

	return Controller.extend("hkmc.ca.zucaa00200.controller.Detail", {
        onInit: function () {
            this.getRoute("RouteDetail").attachPatternMatched(this._onObjectMatched, this);            
        },
        _onObjectMatched: function (oEvent) {
            this._oParameter = oEvent.getParameter("arguments");                
            this.setViewConfig("/layout", sap.f.LayoutType.TwoColumnsMidExpanded);
        }
	});
});