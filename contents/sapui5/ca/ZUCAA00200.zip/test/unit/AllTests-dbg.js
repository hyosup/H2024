sap.ui.define([
	"hkmcca/zucaa00200/test/unit/controller/List.controller"
], function () {
	"use strict";
});
