/*
*******************************************************************
1. Module(Sub) : c.ae
2. Parent Class : sap/ui/core/mvc/Controller
3. Implementation Class : c.ae.zcae000010f01.model.ManageModel
4. Description : ManageModel for Fixed Rate Allocation Factor
*******************************************************************
                        Modification LOG
-------------------------------------------------------------------
No.    CSR/PJT No.    Date          Authors        Description
----   -----------    ----------    -----------    ----------------
001    LGE NEXT ERP   2023.07.05    ThienVHL       Create new
002    LGE NEXT ERP   2023.07.19    ThienVHL       Fix defect
*******************************************************************
Comment:

    No.001 Create ManageModel for Fixed Rate Allocation Factor
    No.002 Fix defect for Fixed Rate Allocation Factor
*******************************************************************
*/
sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/Core",
    "sap/m/List",
    "sap/m/CustomListItem",
    "sap/base/Log"
], function (JSONModel, ODataModel, MessageToast, MessageBox, Core, List, CustomListItem, Log) {
    "use strict";

    let ManagedModel = JSONModel.extend("c.ae.zcae000010f01.model.ManagedModel", {
        /**
         * Constructor function
         */
        constructor: function () {
            JSONModel.prototype.constructor.apply(this, arguments);
            this.aListData = [];
        },

        /**
         * Set Entity function
         * @param {*} sEntity 
         */
        setEntity: function (sEntity) {
            this.sEntity = sEntity;
        },

        setCount : function (sCount) {
            this.sCount = sCount;
        },
       
        getCount: function () {
            return this.sCount;
        },



        /**
         * LoadData from oData Service
         */
        //loadData: function (sURL, aFilters, oViewModel, fnGetText) {
        loadData: function (sURL, aFilters, oViewModel, fnGetText, sControl ) {
            this.sURL = sURL;
            this.ODataModel = new ODataModel({
                serviceUrl: sURL
            });

            this.ODataModel.read("/" + this.sEntity, {
                filters: aFilters,
                success: function (oContent) {
                    let oDataReturned = oContent;                

                    if (oDataReturned) {
                        if (oDataReturned.results && Array.prototype.isPrototypeOf(oDataReturned.results)) {
                            this.aListData = oDataReturned.results;
                            
                            oViewModel.setProperty("/nRows", oDataReturned.results.length); // Count rows count for model
                            this.setJSON(JSON.stringify(this.aListData));   // Set data

                            // Show message when found or not found data
                            if (oDataReturned.results.length > 0) {
                                MessageToast.show(oDataReturned.results.length + fnGetText("searchFound"));
                                sControl.byId("gridTitle01").setText('Fixed Rate Allocation Factor (Total : '+oDataReturned.results.length+')');

                            } else {
                                MessageToast.show(fnGetText("searchNotFound"));
                            }
                        }
                    }
                }.bind(this),
                error: function (oError) {
                    this.showErrorMessage(oError);
                }.bind(this)
            });
        },

        /**
         * Add new data function
         * @param {*} aSelectedItems - List of items selected
         */
        addData: function (aSelectedItems) {
            let aData = this.getData(); // Get data of current model
            
            if(JSON.stringify(aData) == "{}") {
                aData = [];
            }
            // If there are items selected.
            if (aSelectedItems.length > 0) {
                let lastElement = aSelectedItems[aSelectedItems.length - 1];
                for (let i = 0; i < aSelectedItems.length; i++) {
                    aData.splice(lastElement + 1, 0, {"sStatus": "New"});
                }
            } else {
                // If there are no items selected.
                aData.unshift({"sStatus": "New"}); // Add new data at the begining of the table
            }
            // Refresh the model
            this.setData(aData);
        },

        /**
         * Update data function
         * @param {*} oContext - Object is updated data.
         */
        updateData: function (oContext) {
            let oItem = oContext.getObject();
            let aConvertToUpperCase = ["Field_3", "Field_4", "Field_5", "Field_6", "Field_7", "Field_9"];
            let aConvertToString = ["Field_10", "Field_11", "Field_12", "Field_13", "Field_14"];

            // Set update icon
            if (oItem.sStatus !== "New" && oItem.sStatus !== "Delete") {
                oItem.sStatus = "Edit";
            }

            for (let sKey in oItem) {
                // Convert to upper case
                if(aConvertToUpperCase.includes(sKey)) {
                    oItem[sKey] = oItem[sKey].toUpperCase();
                }
                // Convert to string
                if(aConvertToString.includes(sKey)) {
                    oItem[sKey] = oItem[sKey].toString();
                }
            }
        },

        /**
         * Delete Items function
         */
        deleteItems: function (oContext) {
            let sPath = oContext.getPath();
            let oItem = this.getProperty(sPath);

            // Delete immediately record has status New 
            if (oItem.sStatus === "New") {
                let oCurrent = this.getData();
                let index = oCurrent.indexOf(oItem);

                oCurrent.splice(index, 1);
                this.refresh();
            } else {
                oItem.sStatus = "Delete";
                this.refresh();
            }
        },

        /**
         * Submit data changed to data model
         * @param {*} aModel 
         * @param {*} sServiceURL
         * @param {*} fnGetText - call back function to get text from resource bundle
         * @param {*} fnCallBackSuccessFunction - call back function to reload data
         */
        submitData: function (aModel, sServiceURL, fnGetText, fnCallBackSuccessFunction) {
            let oDataModel = new ODataModel({
                serviceUrl: sServiceURL
            });
            let aDataDelete = [];
            let sGroupId = "ManagedModelGroup";

            // Define a new deferred group with sGroupId
            oDataModel.setDeferredGroups([sGroupId]);
            aModel.forEach(oModel => {
                let aDataModel = oModel.getData();
                let aListDataChanged = [];
                let sEntity = oModel.getEntity();
                let sPath;

                aDataModel = JSON.parse(JSON.stringify(aDataModel));

                if (Array.prototype.isPrototypeOf(aDataModel)) {
                    aListDataChanged = aDataModel.filter(function (oData) {
                        return oData.hasOwnProperty("sStatus");
                    });
                }

                // Handle data change
                aListDataChanged.forEach(oDataChange => {
                    switch (oDataChange.sStatus) {
                    case "New":
                        delete oDataChange.sStatus;
                        sPath = "/" + sEntity;
                        oDataModel.create(sPath, oDataChange, {
                            groupId: sGroupId,
                            changeSetId: "Save"
                        });
                        break;
                    case "Edit":
                        delete oDataChange.sStatus;
                        sPath = oDataModel.createKey("/" + sEntity, oDataChange);
                        oDataModel.update(sPath, oDataChange, {
                            groupId: sGroupId,
                            changeSetId: "Save"
                        });
                        break;
                    case "Delete":
                        aDataDelete.push(oDataChange); // Count rows deleted
                        delete oDataChange.sStatus;
                        sPath = oDataModel.createKey("/" + sEntity, oDataChange);
                        oDataModel.remove(sPath, {
                            groupId: sGroupId,
                            changeSetId: "Delete"
                        });
                        break;
                    default:
                        // Do something
                        break;
                    }
                });
            });

            // Submit the changes made to the model to the backend system
            oDataModel.submitChanges({
                groupId: sGroupId,
                success: function (oData, oResponse) {
                    // Check data changed
                    if (JSON.stringify(oData) == "{}") {
                        MessageToast.show(fnGetText("noDataChange"));
                        fnCallBackSuccessFunction();
                    }
                },
                error: function (oError) {
                    this.showErrorMessage(oError);
                }.bind(this)
            });

            // Batch request completed
            oDataModel.attachBatchRequestCompleted(function (oEvent) {
                let aRequests = oEvent.getParameter("requests");
                let aSaveRequests = [],
                    aDeleteRequests = [];
                let nCountDeleteRequest = 0;
                let bSaveErrorFlag = false,
                    oSaveMessageReturn,
                    oDeleteMessageReturn;
                let aListMessages = new List();

                // Request classification from the list of requests
                aRequests.forEach(oRequests => {
                    switch (oRequests.method) {
                    case "MERGE":
                    case "POST":
                        aSaveRequests.push(oRequests);   // Save requests
                        break;
                    case "DELETE":
                        aDeleteRequests.push(oRequests); // Delete requests
                        break;
                    default:
                        // Do something
                        break;
                    }
                });

                // Handel a list of Delete requests
                if (aDeleteRequests.length > 0) {
                    let oDeleteRequest = aDeleteRequests[0];
                    nCountDeleteRequest = aDeleteRequests.length;

                    // Check delete error
                    if (oDeleteRequest.success === false) {
                        oDeleteMessageReturn = new CustomListItem({
                            content: [
                                new sap.m.MessageStrip({
                                    text: fnGetText("deleteFailed"),
                                    showIcon: true,
                                    type: "Error"
                                })
                            ]
                        }); 
                    } else {
                    // Deleted successfully
                        oDeleteMessageReturn = new CustomListItem({
                            content: [
                                new sap.m.MessageStrip({
                                    text: nCountDeleteRequest + " " + fnGetText("deleteSuccessful"),
                                    showIcon: true,
                                    type: "Success"
                                })
                            ]
                        }); 
                    }
                }

                // Handel a list of Save requests
                if (aSaveRequests.length > 0) {
                    let oSaveRequest = aSaveRequests[0];
                    // Check save error
                    if (oSaveRequest.success === false) {
                        let oErrorResponse = JSON.parse(oSaveRequest.response.responseText);
                        
                        bSaveErrorFlag = true;
                        switch (oErrorResponse.error.code) {
                        // Duplicate error
                        case "MC_CSP_USR_RUNTIME/006":
                            oSaveMessageReturn = new CustomListItem({
                                content: [
                                    new sap.m.MessageStrip({
                                        text: fnGetText("duplicateError"),
                                        showIcon: true,
                                        type: "Error"
                                    })
                                ]
                            }); 
                            break;
                        // Key field missing error    
                        case "SABP_BEHV/100":
                            oSaveMessageReturn = new CustomListItem({
                                content: [
                                    new sap.m.MessageStrip({
                                        text: oErrorResponse.error.message.value,
                                        showIcon: true,
                                        type: "Error"
                                    })
                                ]
                            });
                            break;
                            // Exception error
                        default:
                            oSaveMessageReturn = new CustomListItem({
                                content: [
                                    new sap.m.MessageStrip({
                                        text: fnGetText("saveFailed"),
                                        showIcon: true,
                                        type: "Error"
                                    })
                                ]
                            }); 
                            break;
                        }
                    } else {
                        // Save successfully
                        oSaveMessageReturn = new CustomListItem({
                            content: [
                                new sap.m.MessageStrip({
                                    text: fnGetText("saveSuccessful"),
                                    showIcon: true,
                                    type: "Success"
                                })
                            ]
                        }); 

                    }
                }

                // Handel message display
                aListMessages.addItem(oDeleteMessageReturn);
                aListMessages.addItem(oSaveMessageReturn);
                MessageBox.show(aListMessages, {
                    title: "Message"
                });

                if(bSaveErrorFlag === true) {
                    return;
                }
                
                // Reload data
                fnCallBackSuccessFunction();
            });
        },

        /**
         * Get Entity function
         * @returns - Entity
         */
        getEntity: function () {
            return this.sEntity;
        },

        /**
         * Show error function
         * @param {*} oError 
         */
        showErrorMessage: function (oError) {
            sap.ui.core.BusyIndicator.hide();

            let sErrorDetails = oError.responseText ? oError.responseText.toString() : "";

            MessageBox.error(this.getText("ERROR_MSG"));
            Log.error(`${this.getText("ERROR_LOG")}`, `${sErrorDetails}`);
        },

        /**
         * Get text from messagebundle
         * @param {*} sText
         * @returns text from message bundle
         */
        getText: function (sText) {
            return Core.getLibraryResourceBundle("common.lib").getText(sText);
        }
    });

    return ManagedModel;
});