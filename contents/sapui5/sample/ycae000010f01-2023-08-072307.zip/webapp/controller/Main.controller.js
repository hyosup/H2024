/*
*******************************************************************
1. Module(Sub) : c.ae
2. Parent Class : sap/ui/core/mvc/Controller
3. Implementation Class : c.ae.zcae000010f01.Main
4. Description : Fixed Rate Allocation Factor Controller
*******************************************************************
                        Modification LOG
-------------------------------------------------------------------
No.    CSR/PJT No.    Date          Authors        Description
----   -----------    ----------    -----------    ----------------
001    LGE NEXT ERP   2023.07.05    ThienVHL       Create new
002    LGE NEXT ERP   2023.07.19    ThienVHL       Fix defect
*******************************************************************
Comment:

    No.001 Create controller for Fixed Rate Allocation Factor
    No.002 Fix defect for Fixed Rate Allocation Factor
*******************************************************************
*/
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/ManagedModel",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "common/lib/control/ui/excelupload/ExcelUpload",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/export/Spreadsheet"
],
/**
         * @param {typeof sap.ui.core.mvc.Controller} Controller
         */
function (Controller, ManagedModel, JSONModel, MessageToast, MessageBox, ExcelUpload, formatter, Filter, FilterOperator, Spreadsheet) {
    "use strict";
    return Controller.extend("ycae000010f01.controller.Main", {
        formatter: formatter,
        /**
                 * Init data function
                 */
        onInit: function () {
            this.sURL = "/sap/opu/odata/sap/YCAE_SRV_00010_01_UI2_V2/";
            this.sEntity = "YCAE_CR_00010";
            this.oManagedModel = new ManagedModel();
            this.oViewModel = new JSONModel({
                editMode: false,
                nRows: 0
            });
            this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

            this.oManagedModel.setEntity(this.sEntity);
            this.getView().setModel(this.oViewModel, "viewModel");
            this.getView().setModel(this.oManagedModel, "managedModel");


            

            //var oModel = new JSONModel(sap.ui.require.toUrl("ycae000010f01/localService/mockdata/products.json"));
            let oModelProducts = new JSONModel("/localService/mockdata/products.json");
			this.getView().setModel(oModelProducts,"productModel");

			this.byId("productInput").setFilterFunction(function (sTerm, oItem) {
				// A case-insensitive "string contains" style filter
				return oItem.getText().match(new RegExp(sTerm, "i"));
			});
            

            this.byId("productInput").onsapenter = function(e,a,b,c) { // do something 
                MessageBox.alert("For Tcode ");
            }
     

            // https://answers.sap.com/questions/305394/how-to-change-the-text-go-in-smart-filter-bar-to-f.html
            var oFilter = this.getView().byId("filterbar"),
            that = this;

            oFilter.addEventDelegate({
                "onAfterRendering": function(oEvent) {
                    var oResourceBundle = that.getOwnerComponent().getModel("i18n").getResourceBundle();
                    var oButton = oEvent.srcControl._oSearchButton;
                    oButton.setText(oResourceBundle.getText("Search"));
                    oButton.setType("Default");
                }
            });

           //  #application-ycae000010f01-display-component---Main--filterbar-btnFilters
            this.getView().byId("filterbar-btnFilters").setVisible(false); //adapter filter

            let onUpSave = this.getView().byId("onUpSave");
                onUpSave.addStyleClass("onUpSave");
                //onUpSave.placeAt('content');
            
   

        },
        /* */
        onAfterRendering(){
            /*
            var oModel = new JSONModel();
			oModel.setData({
				periodSearchFieldDP : new Date(2016, 1, 16)
			});
			this.getView().setModel(oModel);
            */

            //this.byId("periodSearchFieldDP").setDateValue(new Date(2016, 1, 16));
            this.byId("periodSearchFieldDP").setValue("2023.01");

        },
       

        /**
                * On Exit application function
                */
        onExit: function () {
            if (this.oCustomDialog) {
                this.oCustomDialog.destroy();
            }
        },

        /**
                 * Handle Exit function
                 */
        onExitPress: function () {
            let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
            oCrossAppNavigator.toExternal({ target: { shellHash: "#" } });
        },

        /**
                 * Search data function
                 * @returns 
                 */
        onSearch: function () {
            let oFilterBar = this.getView().byId("filterbar");
            let aFilters = [];
            let bPeriodFlag = false;
            let bCompanyCodeFlag = false;
            let aFilterGroupItems = oFilterBar.getFilterGroupItems();

            aFilterGroupItems.forEach(function (oFilterGroupItem) {
                let oControl = oFilterGroupItem.getControl();
                let sFilterName = oFilterGroupItem.getName();
                let sFilterValue = oControl.getValue();

                // Have value input on Search Field
                if (sFilterValue) {
                    if (sFilterName === "Field_2") {
                        let sFiscalYear = sFilterValue.split(".")[0];

                        aFilters.push(new Filter({
                            path: "Field_1",
                            operator: FilterOperator.EQ,
                            value1: sFiscalYear,
                            and: true
                        }));
                        sFilterValue = sFilterValue.replaceAll(".", "");
                    }

                    aFilters.push(new Filter({
                        path: sFilterName,
                        operator: FilterOperator.EQ,
                        value1: sFilterValue,
                        and: true
                    }));
                    // No value input on Search Field    
                } else {
                    if (sFilterName === "Field_2") {
                        bPeriodFlag = true;
                    } else if (sFilterName === "Field_4") {
                        bCompanyCodeFlag = true;
                    }
                }
            });

            // Handle message for search field
            if (bPeriodFlag) {
                MessageBox.error(this.getText("periodSearchField") + this.getText("required"), {
                    title: "Error"
                });
                return;
            }

            if (bCompanyCodeFlag) {
                MessageBox.error(this.getText("companyCodeSearchField") + this.getText("required"), {
                    title: "Error"
                });
                return;
            }

            if (aFilters.length > 0) {
                //this.oManagedModel.loadData(this.sURL, aFilters, this.oViewModel, this.getText.bind(this));
                this.oManagedModel.loadData(this.sURL, aFilters, this.oViewModel, this.getText.bind(this), this);
            }

        },

        /**
                 * Upload data function
                 */
        onUploadData: function () {
            if (!this.oCustomDialog) {
                const sTemplateUrl = "ycae000010f01/template/Template.xlsx";
                const oInputData = {
                    sModelURL: "/sap/opu/odata/sap/YCAE_SRV_00010_01_UI2_V2/",
                    sEntitySetURL: "/YCAE_CR_00010_EXCEL",
                    sEntityTypeName: "YCAE_CR_00010_EXCELType",
                    sActionLoadDataURL: "/LoadData",
                    sActionSaveDataURL: "/SaveData",
                    aVisibleColumns: ["Field_1", "Field_2", "Field_3", "Field_4", "Field_5", "Field_6", "Field_7",
                        "Field_8", "Field_9", "Field_10", "Field_11", "Field_12", "Field_13", "Field_14", "import_status", "message"],
                    reloadApplicationData: this.reloadApplicationData.bind(this)
                };
                this.oCustomDialog = new ExcelUpload({
                    templateUrl: sTemplateUrl,
                    inputData: oInputData
                });
            }

            this.oCustomDialog.clearDataTable();
            this.oCustomDialog.open();
        },

        /**
                 * Reload data function
                 */
        reloadApplicationData: function () {
            MessageToast.show(this.getText("saveSuccessful"));

            this.oCustomDialog.close();
            this.onSearch();
        },

        /**
                 * Add new data function
                 */
        onAddData: function () {
            let oTable = this.getView().byId("listTable");
            let aSelectItems = oTable.getSelectedIndices();
            this.oManagedModel.addData(aSelectItems);
        },

        /**
                 * Update data function
                 * @param {*} oEvent 
                 */
        onUpdateData: function (oEvent) {
            let oContext = oEvent.getSource().getBindingContext("managedModel");

            this.oManagedModel.updateData(oContext);
        },

        /**
                 * Delete data function
                 * @returns 
                 */
        onDeleteData: function () {
            let oTable = this.getView().byId("listTable");
            let aSelectItems = oTable.getSelectedIndices();

            if (aSelectItems.length < 1) {
                MessageToast.show(this.getText("noRowsSelected"));
                return;
            }

            aSelectItems.reverse().forEach(oData => {
                let oItem = oTable.getContextByIndex(oData);
                this.oManagedModel.deleteItems(oItem);
            });
        },

        /**
                 * Save data function
                 */
        onSave: function () {
            let fnCallBackSuccessFunction = function () {
                this.onSearch();
            }.bind(this);

            this.oManagedModel.submitData([this.oManagedModel], this.sURL, this.getText.bind(this), fnCallBackSuccessFunction);
        },
        onUpSave: function () {
            MessageBox.alert(" onUpSave ");
        },

        onFooterSave: function () {
            MessageBox.alert(" onFooterSave ");
        },

        /**
                 * Cancel function
                 */
        onCancel: function () {
            let oModel = this.getView().getModel("viewModel");
            let btnToggle = this.getView().byId("btnToggle");

            oModel.setProperty("/editMode", false);
            btnToggle.setProperty("pressed", false);
        },

        /**
                 * Handle the press event of the toggle button Edit
                 * @param {*} oEvent 
                 */
        onEdit: function (oEvent) {
            let oModel = this.getView().getModel("viewModel");
            if (oEvent.getSource().getPressed()) {
                oModel.setProperty("/editMode", true);
            } else {
                oModel.setProperty("/editMode", false);
            }
        },

        /**
                 * Get text from resource bundle by key
                 * @param {*} sText 
                 * @returns Text from resource bundle
                 */
        getText: function (sText) {
            return this.oResourceBundle.getText(sText);
        },

        /**
             * Check value input
             * @param {*} oEvent 
             */
        onLiveChange: function (oEvent) {
            let oInput = oEvent.getSource();
            let sValue = oInput.getValue();

            if (isNaN(parseFloat(sValue)) || !isFinite(sValue)) {
                oInput.setValue("");
            }
        }
    });
});
