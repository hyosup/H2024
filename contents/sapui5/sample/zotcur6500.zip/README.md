## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Thu Feb 24 2022 09:17:13 GMT+0900 (대한민국 표준시)|
|**App Generator**<br>@sap/generator-fiori|
|**App Generator Version**<br>1.4.4|
|**Generation Platform**<br>Visual Studio Code|
|**Floorplan Used**<br>simple|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://172.30.158.1:8080/sap/opu/odata/sap/ZOTC_EW_ODATA_SRV
|**Module Name**<br>zotcur6500|
|**Application Title**<br>EWS|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_belize|
|**UI5 Version**<br>Latest|
|**Enable Code Assist Libraries**<br>False|
|**Add Eslint configuration**<br>False|
|**Enable Telemetry**<br>True|

## zotcur6500

조기경보시스템(EWS)

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


