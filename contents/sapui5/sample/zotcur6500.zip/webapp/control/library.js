sap.ui.define([
    "sap/ui/core/BusyIndicator",
    "sap/m/MessageBox",
], function(BusyIndicator, MessageBox){
	sap.ui.getCore().initLibrary({
		name : "control",
		version : "1.0.0",
		dependencies : ["sap.ui.core"],
		types : [
		],
		interfaces : [
		],
		controls: [
		],
		elements : [
		]
	});

	!(function(library){
		library.doSomething = function(sText ) {
			alert('library : '+sText);
		};
		library.getModelOData = function() {
			return sap.ui.getCore().getModel('ODAT');
		};
		library.setModelOData = function(oModel) {
			sap.ui.getCore().setModel(oModel, 'ODAT');
		};
		library.getModelRoot = function() {
			return sap.ui.getCore().getModel('ROOT');
		};
		library.setModelRoot = function(oModel) {
			sap.ui.getCore().setModel(oModel, 'ROOT');
        };
        library.getUserID = function(Model) {
            var userID = "",    //DEFAULT_USER
                userInfo;

            if (sap.ushell){
                userInfo = sap.ushell.Container.getService("UserInfo");
                if (userInfo) {
                    userID = userInfo.getId();
                }
            }
            return userID;
        };

        library.getRfcData = function (that, oView, RFC_CD, objTbl, oData, warningTF) {
            var oModelR = sap.ui.getCore().getModel('ROOT');
            oView.setModel(oModelR);
            oView.bindObject({ path: '/' + 'app' });    //View Name

            var oModel = that.getView().getModel();
            var oModelO = sap.ui.getCore().getModel('ODAT');
            var oFilter = {};// gateway로 보낼 조회조건
            var sEntity = RFC_CD;
            var sEntitySet = '/' + sEntity + 'Set';
            
            oData.login = oModel.getProperty('/app/login');
            // oFilter.input = JSON.stringify(oModel.getProperty('/app/login'));
            oFilter.input = JSON.stringify(oData);
            that.getView().setBusy(true);

            oModelO.read(sEntitySet, {  //'/Z_OTC_IF6500Set'
                async: false,
                filters: library.makeOdataFilter(oFilter),
                success: function (oDataI, response) { // 메세지를 받아오기 위해 response 추가
                    var aReturnData = [];
                    that.getView().setBusy(false);

                    // 결과
                    var ret = false;
                    if (oDataI.results.length > 0 && oDataI.results[0].output) {
                        // Return Data 처리
                        aReturnData = JSON.parse(oDataI.results[0].output);

                        if (aReturnData.es_return) {
                            var sIcon = MessageBox.Icon.NONE;
                            var sReturnType = aReturnData.es_return.mtype;
                            //if (sReturnType != 'S') {
                            if (warningTF) {
                                switch (sReturnType) {
                                    case 'S':   //성공
                                        sIcon = MessageBox.Icon.SUCCESS;
                                        break;
                                    case 'E':   //오류
                                        sIcon = MessageBox.Icon.ERROR;
                                        break;
                                    case 'W':   //경고
                                        sIcon = MessageBox.Icon.WARNING;
                                        break;
                                    case 'I':   //정보
                                        sIcon = MessageBox.Icon.INFORMATION;
                                        break;
                                    case 'A':   //중단
                                        sIcon = MessageBox.Icon.ERROR;
                                        break;
                                    default:
                                        sIcon = MessageBox.Icon.NONE;
                                        break;
                                }

                                MessageBox.show(aReturnData.es_return.message, {
                                    icon: sIcon,
                                    title: sReturnType,
                                    actions: sReturnType != "A" ? [MessageBox.Action.OK] : [MessageBox.Action.ABORT],
                                    onClose: function (oAction) {
                                        if (oAction === 'OK') {
                                            /** */
                                        }
                                    }
                                });
                            }
                        }

                        for (var i = 0; i < objTbl.length; i++) {
                            var tblNm = objTbl[i];
                            var RFC_DATA = [];
                            RFC_DATA = eval("aReturnData." + tblNm);

                            if(RFC_CD == "Z_OTC_IF6505" && tblNm == "et_list")
                            {
                                oModel.setProperty('/app/s_list', RFC_DATA); //검색에서 et_list를 사용
                            }
                            else
                            {
                                oModel.setProperty('/app/' + tblNm, RFC_DATA); //
                            }
                        }

                        ret = true;
                    }

                    that.getView().setBusy(false);
                    that.onCallback(oModel, RFC_CD, oData.ptype);
                },
                error: library.fnDisplayError.bind(that)
            });

        };

        library.fnSetHomeScr = function(oModel)
        {
            var et_my_sum = [];
            et_my_sum = oModel.getProperty("/app/et_my_sum");
            var text = "<br>";
            for(var i=0; i<et_my_sum.length; i++)
            {
                text += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+et_my_sum[i].sum_text+"<br/>";
            }
            
            oModel.setProperty("/app/Tile", text);

//            var arr = [{col:''}];
//            arr[0].col = text;
//            oModel.setProperty("/app/Tile", arr);


            var R_DATA = [];
            R_DATA = oModel.getProperty('/app/et_my_ri'); //
            
            var EXECYL="";//M’  => “매월” + ZDAY + “일” 로 표기
                            //‘W’  => “매주” + WKNUM로 만든 요일 로 표기
                            //‘D’  => “매일” + EXETIM + “시” 로 표기
            
            for(var i=0; i<R_DATA.length; i++)
            {
                //주기 컬럼 -시작
                EXECYL = R_DATA[i].execyl;

                switch(EXECYL)
                {
                    case "M":
                        R_DATA[i].execyltxt = "매월 "+R_DATA[i].zday+"일 "+ R_DATA[i].exetim+"시";
                    break;
                    case "W":
                        var week = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
                        var wknumTxt = week[R_DATA[i].wknum];
                        R_DATA[i].execyltxt = "매주 "+wknumTxt+" "+ R_DATA[i].exetim+"시";
                    break;
                    case "D":
                        R_DATA[i].execyltxt = "매일 "+R_DATA[i].exetim+"시";
                    break;
                    default:
                        R_DATA[i].execyltxt = "";
                }
                //주기 컬럼 -종료

                //상태 컬럼-시작
                if(R_DATA[i].stat == "S")
                {
                    R_DATA[i].stat_txt = "구독";
                }else if(R_DATA[i].stat == "H"){
                    R_DATA[i].stat_txt = "일시중지";
                }else{
                    R_DATA[i].stat_txt = "";
                }
                //상태 컬럼-종료

                //편집 수정컬럼-시작
                var slogIn = oModel.getProperty('/app/login');
//alert(slogIn.logid+", "+R_DATA[i].email);                                
                if(R_DATA[i].xmndty == '')
                {
                    R_DATA[i].updYn = true;
                }else{
                    R_DATA[i].updYn = false;
                }
                //편집 수정컬럼-종료

                var datalist = (""+R_DATA[i].datalist).replaceAll("|n", "\r\n");
                R_DATA[i].datalist = datalist;
            }
            R_DATA = oModel.setProperty('/app/et_my_ri', R_DATA); //
        };

        library.fnSetRiskTable = function(oModel)
        {
            //var oModel = this.getView().getModel();
            var et_ri = oModel.getProperty("/app/et_ri");
            for(var i=0; i<et_ri.length; i++)
            {
                var execyl = et_ri[i].execyl;

                if(execyl == "D")
                {
                    //et_ri[i].execylTxt = "매일 "+ et_ri[i].exetim+"시";
                    et_ri[i].execylTxt = "일 1회 구독하기";
                }
                else if(execyl == "W")
                {
                    //var week = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"];
                    //et_ri[i].execylTxt = "매주 "+week[et_ri[i].wknum]+" "+ et_ri[i].exetim+"시";
                    et_ri[i].execylTxt = "주 1회 구독하기";
                }
                else if(execyl == "M")
                {
                    //et_ri[i].execylTxt = "매월 "+et_ri[i].zday+"일 "+ et_ri[i].exetim+"시";
                    et_ri[i].execylTxt = "월 1회 구독하기";
                }

                et_ri[i].circleDis=true;
                if(et_ri[i].stat == "S") et_ri[i].icon = "sap-icon://complete";
                else if(et_ri[i].stat == "H") et_ri[i].icon = "sap-icon://stop";
                else et_ri[i].circleDis = false;
            }

            oModel.setProperty("/app/et_ri", et_ri);
        };

        library.fnSetRiskItem = function(oModel)
        {
            //var s_list = oModel.getProperty("/app/et_list");
            //oModel.setProperty("/app/s_list", s_list);
        };

        library.fnDisplayError = function(oEvent) {
            this.getView().setBusy(false);
            
            var oMessage = JSON.parse(oEvent.responseText);
            var sMessage = '';
            if (oMessage.error.innererror.hasOwnProperty('errordetails')) {
                oMessage.error.innererror.errordetails.forEach(function(oItem){
                    sMessage += oItem.message+'\n';
                });
            } else {
                sMessage += oMessage.error.innererror.Error_Resolution.SAP_Transaction;
            }

            
            MessageBox.show(sMessage, {
                icon: MessageBox.Icon.ERROR,
                title:"Error",
                actions: [MessageBox.Action.OK]
            });
        };
            
		library.makeOdataFilter = function(oFilter) {
            var mFilter = [];
            
            for(var sKey in oFilter) {
                var oVal = oFilter[sKey];

                if(!(oVal instanceof Object) || oVal instanceof Date) {
                    if(oVal) {
                        mFilter.push(new sap.ui.model.Filter({
                            path: sKey,
                            operator: sap.ui.model.FilterOperator.EQ,
                            value1: oVal
                        }));
                    }
                // Array로 입력된 Tokens값 처리
                } else if(Array.isArray(oVal)) {
                    if(oVal.length > 0) {
                        for (var sArrayKey in oVal) {
                            var oFilterVal = oVal[sArrayKey];
    
                            mFilter.push(new sap.ui.model.Filter({
                                path: sKey,
                                operator: oFilterVal.operation,
                                value1: oFilterVal.value1,
                                value2: oFilterVal.value2
                            }));
                        }
                    }
                    
                    } else {
                    mFilter.push(new sap.ui.model.Filter({
                        path: sKey,
                        operator: sap.ui.model.FilterOperator.BT,
                        value1: oVal.value1,
                        value2: oVal.value2
                    }));
                }
            }

			return mFilter;
		};

        

        library.columnFactory = function(sId, oContext) {
            var that = this;
            var oModel = this.getView().getModel();
            var sColumnName = oContext.sPath.replace('/app/columns/', '');
            var sColumnWidth = "8rem";

            return new Column(sId, {
                visible: true,
                sortProperty: true,
                filterProperty: true,
                width: sColumnWidth,
                label: new Label({text: sColumnName}),
                hAlign: "Begin",
                template: new Text({text: {path: sColumnName}, wrapping: false})
            });
        }
	}(control));
	
	return control;
});