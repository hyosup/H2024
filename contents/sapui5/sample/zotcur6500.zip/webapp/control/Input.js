/**
* System : BNT UI5<br>
* Module : Library<br>
* Creator: acoty<br>
* Date   : 2021.09.09<br>
* Description : KOLON BNT UI5 Library<br>
*---------------------------------------------------------------------------------------<br>
* 변경일 변경자 변경내역<br>
*---------------------------------------------------------------------------------------<br>
**/
sap.ui.define([
	'sap/ui/comp/library',
	'sap/ui/core/Control',
	'sap/ui/model/json/JSONModel',
	'sap/ui/model/type/String',
	'sap/m/ColumnListItem',
	'sap/m/Label',
	'sap/m/SearchField',
	'sap/m/Input',
	'sap/m/MessageToast',
	'sap/m/Token',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
], function(compLibrary, Control, JSONModel, typeString, ColumnListItem, Label, SearchField, Input, MessageToast, Token, Filter, FilterOperator) {
	"use strict";
	return Input.extend('bnt.control.Input', {
		metadata: {
			properties: {
				contents: {
					type: "object",
					defaultValue: {
						shlpname: '',
						shlptype: '',
						lang: sap.ui.getCore().getConfiguration().getLanguage(),
						selopt: [],
						keys: '',
						opt: [],
						displayfield: [],
						xmulti: '',		// 다중 선택 여부
						blazy: ''		// 초기 조회 여부 (shelplist)
					}
				}
			},
			aggregations: {},
			events: {}
		},
		
		init: function() {
			Input.prototype.init.call(this);

			this.oDataModel = sap.ui.getCore().getModel('ODAT');
			this.oModelR = sap.ui.getCore().getModel('ROOT');	//new sap.ui.model.json.JSONModel();
			if (typeof this.oModelR.getProperty('/valueHelp') === 'undefined') {
				this.oModelR.setProperty('/valueHelp', {});
			}
			
			this.attachValueHelpRequest(this.onValueHelpRequest);
			this.addStyleClass('bntui5');
		},
//		onBeforeRendering: function() {			
//		},
		renderer: function(oRm, oInput) {
			sap.m.InputRenderer.render(oRm, oInput);	//InputRenderer
		},
		
		/*
		 * Create Filter
		 */
		_createFilterGroupItem: function (sId, oContext) {
			var that = this;
			var oData = oContext.getObject();
			var oInput = new sap.m.Input({
				name: oData['fieldname'],
				maxLength: oData['leng'],
				submit: function (event) {
					that._oValueHelpDialog.getFilterBar().search();
				}
			});
			var oFilterGroupItem = new sap.ui.comp.filterbar.FilterGroupItem({
				groupName: '__$INTERNAL$',
				name: oData['fieldname'],
				label: oData['scrtext_m'],	//sap.ui.Device.system.phone ? oData['scrtext_m'] : oData['scrtext_l'],
				labelTooltip: oData['scrtext_l'],
				visibleInFilterBar:true,
				control: oInput
			});
			
			return oFilterGroupItem;
		},
		
		_getShlpOdata: function () {
			var that = this;
			var oDataR = {}
			oDataR = {
//				[{ "shlpfield" : "bukrs", "sign" : "I", "option" : "EQ", "low" : "K000", "high" : "" }]
				shlpname : this.getContents().shlpname,
				selopt: JSON.stringify(this.getContents().selopt),
				lang : sap.ui.getCore().getConfiguration().getLanguage()
			};

			this.getContents().selopt = [];
			
			var sPath = this.getContents().shlpname;	//'/valueHelp/'+this.oDataR.shlpname;
			var sKey = this.oDataModel.createKey('/VALUEHELPSet', oDataR);	//this.oDataR
			this.oDataModel.read(sKey,{
				async : false,
		        success: function(oDataI){
					var jModel = sap.ui.getCore().getModel('ROOT');
//					jModel.setProperty(sPath+'/', {});
//					jModel.setProperty(sPath+'/info', JSON.parse(oDataI.info));
//					jModel.setProperty(sPath+'/field', JSON.parse(oDataI.field));
					jModel.setProperty(sPath+'/result', JSON.parse(oDataI.result));
			    },
			    error: function(e){
			        debugger;
			    	alert('error..oDataModel.read');
			    }
		    });
			
			var oFilter = new Filter({
				filters: [],	//aFilters,
				and: true
			});
			
			var oValueHelpDialog = this._oValueHelpDialog;

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
			
		},
		
		/*
		 * 필터 실행
		 */
		_onSearchs: function (oEvent) {
			var that = this;
//				var sSearchQuery = this._oBasicSearchField.getValue();
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				var it = that;
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName().toLowerCase(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
					
//					[{ shlpfield: "", sign="", option="", low="", high="" }]
					var oItem = {};
					oItem.shlpname = it.getContents().shlpname;
					oItem.shlpfield = oControl.getName().toUpperCase();
					oItem.sign = 'I';
					//oItem.option = sap.ui.model.FilterOperator.EQ;
					oItem.low = oControl.getValue();

					if((""+oItem.low).indexOf("*") > -1)
					{
						oItem.option = sap.ui.model.FilterOperator.CS;
					}
					else
					{
						oItem.option = sap.ui.model.FilterOperator.EQ;
					}

					oItem.high = '';
					if (!it.getContents().hasOwnProperty('selopt')) {
						it.getContents().selopt = [];
					}
					it.getContents().selopt.push(oItem);
				}
			
				return aResult;
			}, []);
			
			/*
			 * opt 정보 가져오기
			 */
			var oRootModel = sap.ui.getCore().getModel('ROOT');	//this.getModelRoot();
			var oOpt = [];
			var oOptTemp = this.getContents().opt;
			if(this.getContents().opt && oOptTemp.length > 0) {
				//this.getContents().opt = []
				for(var i=0; i<oOptTemp.length; i++) {
					var oItem = {};
					
					oItem.shlpname = '';
					oItem.shlpfield = oOptTemp[i].param;
					oItem.sign = 'I';
					oItem.option = sap.ui.model.FilterOperator.EQ;
					oItem.low = oRootModel.getProperty(oOptTemp[i].path) !== null ? oRootModel.getProperty(oOptTemp[i].path) : oOptTemp[i].path;
					oItem.high = '';
					
					oOpt.push(oItem);
				}				
			}
			
			var oShlpInfo = {
				shlpname : that.getContents().shlpname,	//H_T001, ZPLS_PGROUP
				shlptype : that.getContents().shlptype ? that.getContents().shlptype : 'S',
				selopt: JSON.stringify(that.getContents().selopt),
				opt : JSON.stringify(oOpt),
				lang: sap.ui.getCore().getConfiguration().getLanguage(),
				shlplist: 'X'
			};
			this.oDataR = {
				input : JSON.stringify(oShlpInfo)
			};
			that.getContents().selopt = [];
			
			var sPath = '/valueHelp/' + oShlpInfo.shlpname;
			var sKey = that.oDataModel.createKey('/VALUEHELPSet', this.oDataR);
			that.oDataModel.read(sKey,{
				async : true,
		        success: function(oDataI){
					var jModel = sap.ui.getCore().getModel('ROOT');
					var oResults = JSON.parse(oDataI.output);
//					jModel.setProperty(sPath+'/', {});
//					jModel.setProperty(sPath+'/info', JSON.parse(oDataI.info));
//					jModel.setProperty(sPath+'/field', JSON.parse(oDataI.field));
					jModel.setProperty(sPath+'/result', oResults.dy_table);	//JSON.parse(oDataI.result));

					that._oValueHelpDialog.update();
			    },
			    error: function(e){
			        debugger;
			    	alert('error..oDataModel.read');
			    }
		    });
		},
		
		onValueHelpRequest: function(oEvent) {
			var that = this;
			var oModelR = sap.ui.getCore().getModel('ROOT');

			if (!this.getShowValueHelp()) {
				return;
			}

			// oModelR.setProperty('/valueHelp', {});
			
			/*
			 * opt 정보 가져오기
			 */
			var oOpt = [];
			var oOptTemp = this.getContents().opt;
			if(this.getContents().opt && oOptTemp.length > 0) {
				//this.getContents().opt = []
				for(var i=0; i<oOptTemp.length; i++) {
					var oItem = {};
					
					oItem.shlpname = '';
					oItem.shlpfield = oOptTemp[i].param;
					oItem.sign = 'I';
					oItem.option = sap.ui.model.FilterOperator.EQ;
					oItem.low = oModelR.getProperty(oOptTemp[i].path) !== null ? oModelR.getProperty(oOptTemp[i].path) : oOptTemp[i].path;
					oItem.high = '';
					
					oOpt.push(oItem);
				}				
			}
			/*
			 * Get oData	'{param : "IV_PROID", path : "ZPLSE4000K"}'
			 */
			var oShlpInfo = {
				shlpname : this.getContents().shlpname,	//H_T001, ZPLS_PGROUP
				shlptype : !this.getContents().shlptype ? 'S' : this.getContents().shlptype,
				selopt: '',
				opt : JSON.stringify(oOpt),
				lang : sap.ui.getCore().getConfiguration().getLanguage(),
				shlplist: that.getContents().blazy
			};
			this.oDataR = {
				input : JSON.stringify(oShlpInfo)
			};

			var sPath = '/valueHelp/' + oShlpInfo.shlpname;	//this.oDataR.shlpname;
			var sKey = this.oDataModel.createKey('/VALUEHELPSet', this.oDataR); 
		    this.oDataModel.read(sKey,{
				async : false,
		        success: function(oDataI) {
					// var aTempField = JSON.parse(oDataI.field);
					var oResults = JSON.parse(oDataI.output);
					var aTempField = oResults.fielddescr;
					var aOdataField = [];
					if (that.getContents().displayfield instanceof Array && that.getContents().displayfield.length != 0){
						for(var i=0; i<aTempField.length; i++) {
							for(var sKey in that.getContents().displayfield){
								if (aTempField[i].fieldname == that.getContents().displayfield[sKey]) {
									aOdataField.push(aTempField[i]);
								}								
							}
						}
						if (aOdataField.length == 0) {
							aOdataField = aTempField;
						}
					} else {
						aOdataField = aTempField;			
					}
					
					oModelR.setProperty(sPath + '/', {
		        		info: oResults.shlpinfo,	//JSON.parse(oDataI.info),
		        		field: aOdataField,			//JSON.parse(oDataI.field),
		        		result: oResults.dy_table	//JSON.parse(oDataI.result)
					});
		        	
					that._oValueHelpDialog.update();
			    },
			    error: function(e){
			        debugger;
			    	alert('error..oDataModel.read');
			    }
		    });


			// this._oBasicSearchField = new SearchField({
		    //     showSearchButton: sap.ui.Device.system.phone,
		    //     placeholder: "Search",
		    //     search: function(event) {
		    //     	that._oValueHelpDialog.getFilterBar().search();
		    //     }
			// });
			
			this._oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				// useToolbar: false,
				// basicSearch: this._oBasicSearchField,
				showGoOnFB: true,	//!sap.ui.Device.system.phone
				searchEnabled: true,
				filterGroupItems : {
					path : sPath+'/field',
					factory: this._createFilterGroupItem.bind(this)
				},
				search : this._onSearchs.bind(this)
			});

			if (!this._oFilterBar.getFilterBarExpanded()) {
				this._oFilterBar.setFilterBarExpanded(true);
			}

			// var xmultiTF = false;
			// if(oShlpInfo.xmulti == "X") xmultiTF = true;
			
			this._oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: "",
				title: {
					path : sPath+'/info/ddtext'
				},
				//supportMultiselect: false,
				supportMultiselect : this.getContents().xmulti === 'X' ? true : false,
				supportRanges: false,
				// supportRangesOnly: false,
				key: this.getContents().keys,
				descriptionKey : this.getContents().texts ? this.getContents().texts : this.getContents().keys,
				// stretch: sap.ui.Device.system.phone,
				tokenDisplayBehaviour: 'descriptionOnly',
				// RangeKeyFields : [{}],
				ok : function(oEvent) {
					var aTokens = oEvent.getParameter("tokens");
					var oContext = that.getBindingContext();
					
					var getKeys = "";
					if(that.getContents().xmulti === 'X')	//xmultiTF
					{
						var gu=",";
						for(var xx=0; xx < aTokens.length; xx++)
						{
							if(xx == aTokens.length-1) gu = "";
							getKeys += aTokens[xx].getKey()+gu;
						}
					}
					else
					{
						//that.setValue(aTokens[0].getKey());	//aTokens[0].getText()
						getKeys = aTokens[0].getKey();
					}
					that.setValue(getKeys);	//aTokens[0].getText()
					
					if (oContext) {
					// 	oContext.getModel().setProperty(oContext.getPath()+'/'+that.getContents().texts, aTokens[0].getText());
						//that.setTooltip(aTokens[0].getText());
						that.setTooltip(getKeys);
					}
					
					that.fireChange();
					that._oValueHelpDialog.close();
				},
				cancel : function(oEvent) {
					that._oValueHelpDialog.close();
				},
				afterOpen : function(oEvent) {
					that._oValueHelpDialog.getFilterBar().setFilterBarExpanded(true);
				},
				afterClose : function(oEvent) {
					that._oValueHelpDialog.destroy();
				},
				filterBar : this._oFilterBar
			});

			this._oValueHelpDialog.setModel(oModelR);

			this._oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.bindAggregation("rows", sPath + "/result");
				}

				if (oTable.bindColumns) {
					oTable.setEnableCellFilter(true);
					oTable.setEnableColumnReordering(true);

					oTable.bindAggregation("columns", sPath + '/field', function (sId, oContext) {
						var oData = oContext.getObject();
						var sPath = oData['fieldname'].toLowerCase();

						var aFieldTextS = new sap.m.Label({ text: '{scrtext_s}' });
						var aFieldTextL = new sap.m.Label({ text: '{scrtext_l}' });
						var sHeadlen = oData['headlen'] + 'rem';

						return new sap.ui.table.Column({
							label: sap.ui.Device.system.phone ? aFieldTextS : aFieldTextL,
							sortProperty: sPath,
							filterProperty: sPath,
							// width: sHeadlen,
							template: new sap.m.Text({ text: '{' + sPath + '}', wrapping: false })
						});
					});
				}

				if (oTable.bindItems) {
					oTable.setIncludeItemInSelection(true);	//clicking on the item itself

					oTable.bindAggregation("columns", sPath + '/field', function (sId, oContext) {
						var oData = oContext.getObject();
						var iPosition = oData['position'];

						return new sap.m.Column({
							header: new sap.m.Label({ text: '{scrtext_m}', design: 'Bold' }),
							demandPopin: true,
							minScreenWidth: iPosition === 1 ? sap.m.ScreenSize.Phone : sap.m.ScreenSize.Desktop
						});
					});
					oTable.bindAggregation("items", sPath + '/result', function () {
						var aCols = oModelR.getProperty(sPath + '/field');
						return new sap.m.ColumnListItem({
							cells: aCols.map(function (column) {
								return new sap.m.Text({ text: '{' + column.fieldname + '}' });
							})
						});
					});
				}

				this._oValueHelpDialog.update();
			}.bind(this));
			
			this._oValueHelpDialog.open();
		}
		
	});		
});
