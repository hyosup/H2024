sap.ui.define([
	"zotcur6500/test/unit/controller/App.controller"
], function () {
	"use strict";
});
