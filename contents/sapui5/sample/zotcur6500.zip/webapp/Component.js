sap.ui.define([
        "sap/ui/core/UIComponent",
        "sap/ui/Device",
        "sap/ui/model/odata/v2/ODataModel",
        "zotcur6500/model/models",
        "control/library"
    ],
    function (UIComponent, Device, ODataModel, models, library) {
        "use strict";

        return UIComponent.extend("zotcur6500.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");

                // set App model
                var sUrl = '/sap/opu/odata/sap/ZOTC_EW_ODATA_SRV/';			
                sap.ui.getCore().setModel(
                    new ODataModel(sUrl, {
                        json:true, 
                        useBatch:false, 
                        defaultUpdateMethod:'Put',
                        metadataUrlParams: { 'sap-client': '100' }
                    }
                ), 'ODAT');
                
                var oModelO = sap.ui.getCore().getModel('ODAT');
                oModelO.setHeaders({
                    "AppId": this.getMetadata().getManifestEntry("sap.app").id
                });

                sap.ui.getCore().setModel(
                    new sap.ui.model.json.JSONModel({
                        app: {
                            odata : [
                                {key: 'Z_OTC_IF6500', text: '[EW] 업무 리스트'},
                                {key: 'Z_OTC_IF6501', text: '[EW] 내 구독 리스트'},
                                {key: 'Z_OTC_IF6502', text: '[EW] 조기경보 리스트'},
                                {key: 'Z_OTC_IF6503', text: '[EW] 항목 상세'},
                                {key: 'Z_OTC_IF6504', text: '[EW] 검색'},
                                {key: 'Z_OTC_IF6505', text: '[EW] 제안'},
                                {key: 'Z_OTC_IF6506', text: '[EW] 구독 샘플 발송'}
                            ],
                            login : {
                                appid : "zotcur6500",
                                sysid : library.getUserID(),
                            },
                            visibleTF : "first",
                            ptype : 'R',	    //프로세스타입(C:생성,R:조회.U변경,D:삭제)
                            bizno : '10001',    //영역분류코드
                            rpno : '',		    //Point 번호
                            rino : '10001',     //Item 번호
                            subno : '',	        //구독번호
                            keyword : '',	    //검색어
                            range : '',	        //ABAB 딕셔너리: 두 자리 숫자 필드
                            idea : [            //[EW] Risk Item 제안
                                {subjt : '테스트', sys : 'DEV', scrn : '1000', ztext : 'TEST'}
                            ],
                            items : [],
                            columns: {},
                            worklist: [
                                { bizno: 'MY', biznm: 'My' },
                                { bizno: 'SEARCH', biznm: '검색' },
                                { bizno: 'BIZ01', biznm: '영업' },
                                { bizno: 'BIZ02', biznm: '생산' },
                                { bizno: 'BIZ03', biznm: 'Risk' },
                                { bizno: 'BIZ04', biznm: 'Risk Item' }
                            ],
                            ipAddress : this.getIpAddress(),
                            //sysip : $.getJSON('http://ip.jsontest.com/', function(data) {
                            //    JSON.stringify(data, null, 2);
                            //}),
                            sysip : this.getIpAddress(),

                            screenNm : 'Home',
                            selectView : false,
                            selectKey  : '',
                            risk_bizno : '',    //동적 메뉴에서 클릭했을 경우 해당 메뉴의 bizno 저장
                            lt_biz : [],        //Z_OTC_IF6500

                            et_my_sum : [],     //Z_OTC_IF6501
                            et_my_rp : [],      //Z_OTC_IF6501
                            et_my_ri : [],      //Z_OTC_IF6501
                            it_my_ri : [],      //Z_OTC_IF6501

                            et_rp : [],         //Z_OTC_IF6502
                            et_ri : [],         //Z_OTC_IF6502

                            click_rpno : '',    //홈, My, 가변메뉴화면에서 좌측리스트 클릭시 rpno 저장
                            pop_subno : '',     //팝업의 좌측 리스트에서 선택한 SUBNO
                            pop_et_ri : [],     //Z_OTC_IF6503
                            pop_et_ri_dtl : [],    //Z_OTC_IF6503
                            pop_et_var_field : [], //Z_OTC_IF6503
                            pop_et_sub : [],       //Z_OTC_IF6503
                            pop_et_var_data : [],  //Z_OTC_IF6503
                            pop_it_sub : [
                                {subno:''
                                ,rino:''
                                ,email:''
                                ,xmndty:''
                                ,stat:''
                                ,lvorm:''
                                ,exetim:'0'
                                ,wknum:''
                                ,zday:''
                                ,iesign:''
                                ,value:''
                                ,rmk:''
                                }
                            ],     //Z_OTC_IF6503
                            pop_it_var_data: [], //Z_OTC_IF6503
                            et_list: []          //Z_OTC_IF6504
                            ,riskItem_enabled : true
                        }
                }), 'ROOT');
                
                this.setModel(sap.ui.getCore().getModel('ROOT'));
            },

            getIpAddress : function()
            {
                var ip = false;
                window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection || false;

                if (window.RTCPeerConnection)
                {
                    ip = [];
                    var pc = new RTCPeerConnection({iceServers:[]}), noop = function(){};
                    pc.createDataChannel('');
                    pc.createOffer(pc.setLocalDescription.bind(pc), noop);

                    
                    pc.onicecandidate = function(event)
                    {
                        if (event && event.candidate && event.candidate.candidate)
                        {
                            var s = event.candidate.candidate.split('\n');
                            ip.push(s[0].split(' ')[4]);
                        }
                    }
                }

                return ip;
            },

            getIpClient : function()
            {
                var arr = this.getIpClient2();
                alert(arr);

                return arr;
            },
            getIpClient2 : function () 
            {
                /*var interfaces = require('os').networkInterfaces();

                for (var devName in interfaces) {
                  var iface = interfaces[devName];
                    alert(iface.length);
                  for (var i = 0; i < iface.length; i++) 
                  {
                    var alias = iface[i];
                    if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal)
                      return alias.address;
                  }
                }
*/
                return $.getJSON('http://ip.jsontest.com/', function(data) {
                    JSON.stringify(data, null, 2);
                });
            }
        });
    }
);