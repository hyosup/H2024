sap.ui.define([
    "sap/ui/core/Core",
	"sap/ui/core/library",
    "control/library",
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Core, CoreLibrary, library, Controller, MessageBox) {
        "use strict";

        var that;
        return Controller.extend("zotcur6500.controller.RiskItem", {
            onInit: function () 
            {
                this.oOwnerComponent = this.getOwnerComponent();
                this.oRouter = this.oOwnerComponent.getRouter();
                this.oRouter.attachRouteMatched(this.onRouteMatched, this);
                this.oRouter.attachBeforeRouteMatched(this.onBeforeRouteMatched, this);
            },

            onBeforeRouteMatched: function(oEvent) 
            {
                var oModel = this.oOwnerComponent.getModel(),
                	sLayout = oEvent.getParameters().arguments.layout,
                	oNextUIState;

            },

            onRouteMatched: function (oEvent) 
            {
                var sRouteName = oEvent.getParameter("name"),
                    oArguments = oEvent.getParameter("arguments");

                // Save the current route name
                this.currentRouteName = sRouteName;
                this.currentProduct = oArguments.product;
            },

            onSave: function(oEvent)
            {
                var that = this;
                var oView = this.getView();
                var oModel = this.getView().getModel();

                var it_idea = [{bizno:'', biznm:'', rpnm:'', subjt:'', sys:'', scrn:'', ztext:'', seqno:''}];
                it_idea[0].bizno   = this.byId("bizno").getSelectedKey();
                it_idea[0].rpnm    = this.byId("rpnm").getValue();
                it_idea[0].subjt   = this.byId("subjt").getValue();
                it_idea[0].sys     = this.byId("sys").getValue();
                it_idea[0].scrn    = this.byId("scrn").getValue();
                it_idea[0].ztext   = this.byId("ztext").getValue();
                it_idea[0].seqno   = this.byId("seqno").getValue();

                if(it_idea[0].bizno == undefined || it_idea[0].bizno == '')
                {
                    MessageBox.alert("영역을 선택하세요.");
                    return false;
                }

                var objTbl = ["it_idea", "et_list"];
           
                // Input Data 설정
                var oData = {};
                oData.ptype = "U";
                oData.it_idea = it_idea;

                library.getRfcData(that, oView, "Z_OTC_IF6505", objTbl, oData, false);
            },

            onReset: function(oEvent)
            {   that = this;
                var oModel = this.getView().getModel();
                MessageBox.confirm("입력한 모든 내용을 지우시겠습니까?", 
                {
                    actions: ["Ok", MessageBox.Action.CLOSE],
                    emphasizedAction: "Manage Products",
                    onClose: function (sAction) 
                    {
                        if(sAction != "CLOSE")
                        {
                            that.byId("bizno").setSelectedKey("");
                            that.byId("rpnm").setValue("");
                            that.byId("subjt").setValue("");
                            that.byId("sys").setValue("");
                            that.byId("scrn").setValue("");
                            that.byId("ztext").setValue("");
                            that.byId("seqno").setValue("");

                            oModel.setProperty("/app/riskItem_enabled", true);
                        }
                    }
                });
            },

            onCallback: function(oModel, RFC_CD, ptype)
            {
                switch(RFC_CD)
                {
                    case "Z_OTC_IF6505":
                        MessageBox.success("저장 되었습니다.");

                        this.byId("bizno").setSelectedKey("");
                        this.byId("rpnm").setValue("");
                        this.byId("subjt").setValue("");
                        this.byId("sys").setValue("");
                        this.byId("scrn").setValue("");
                        this.byId("ztext").setValue("");
                        break;
                }
            },

            onCellClick: function(oControlEvent)
            {
                var rowIdx = ""+oControlEvent.getParameters().rowIndex;
                var oModel = this.getView().getModel();
                var list = oModel.getProperty("/app/s_list");

                this.byId("bizno").setSelectedKey(list[rowIdx].bizno);
                this.byId("rpnm").setValue(list[rowIdx].rpnm);
                this.byId("subjt").setValue(list[rowIdx].subjt);
                this.byId("sys").setValue(list[rowIdx].sys);
                this.byId("scrn").setValue(list[rowIdx].scrn);
                this.byId("ztext").setValue(list[rowIdx].ztext);
                this.byId("seqno").setValue(list[rowIdx].seqno);

                if(list[rowIdx].chkid == '')
                {
                    oModel.setProperty("/app/riskItem_enabled", true);

                }
                else
                {
                    oModel.setProperty("/app/riskItem_enabled", false);
                }
            }
            
        });
    });
