sap.ui.define([
	"sap/ui/core/Core",
    "sap/ui/export/Spreadsheet",
    'sap/base/util/deepExtend',
	"sap/ui/core/library",
    "control/library",
    "./PopController",
    "sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
    "sap/ui/table/Column",
	"sap/m/Label",
	"sap/m/Text",
    "sap/base/Log",
    'sap/ui/model/BindingMode',
    "sap/ui/model/json/JSONModel",
    'sap/ui/core/Fragment',
	"sap/ui/Device",
	"sap/ui/core/syncStyleClass"
], 
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Core, Spreadsheet, deepExtend, CoreLibrary, library, Controller, ODataModel, MessageBox, MessageToast, Column, Label, Text, Log, BindingMode, JSONModel, Fragment, Device, syncStyleClass) {
        "use strict";

        return Controller.extend("zotcur6500.controller.Home", 
        {
            
            onInit: function () {
                
                var that = this;
                var oView = this.getView();
                
                /*var objTbl = ["et_my_sum", "et_my_rp", "et_my_ri"];
            
                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                library.getRfcData(that, oView, "Z_OTC_IF6501", objTbl, oData, false); */
           },

            

            onCallback: function(oModel, RFC_CD, ptype)
            {
                switch(RFC_CD)
                {
                    case "Z_OTC_IF6501":
                        if(ptype == "R")
                        {
                            library.fnSetHomeScr(oModel);
                        }
                        else if(ptype == "D")
                        {
                            MessageBox.success("삭제 되었습니다.");
                            library.fnSetHomeScr(oModel);
                        }
                        break;
                    case "Z_OTC_IF6506":
                        MessageBox.success("발송 되었습니다.");
                        break;
                    default:
                }
            },

            onBeforeRouteMatched: function(oEvent) {
                var oModel = this.oOwnerComponent.getModel(),
                	sLayout = oEvent.getParameters().arguments.layout,
                	oNextUIState;
            },

            onRouteMatched: function (oEvent) {
                var sRouteName = oEvent.getParameter("name"),
                    oArguments = oEvent.getParameter("arguments");

                // Save the current route name
                this.currentRouteName = sRouteName;
                this.currentProduct = oArguments.product;
            },

            handleLoadItems: function(oControlEvent) {
                oControlEvent.getSource().getBinding("items").resume();
            },
    
            fnDisplayError : function(oEvent) {
                this.getView().setBusy(false);
                
                var oMessage = JSON.parse(oEvent.responseText);
                var sMessage = '';
                if (oMessage.error.innererror.hasOwnProperty('errordetails')) {
                    oMessage.error.innererror.errordetails.forEach(function(oItem){
                        sMessage += oItem.message+'\n';
                    });
                } else {
                    sMessage += oMessage.error.innererror.Error_Resolution.SAP_Transaction;
                }
    
                
                MessageBox.show(sMessage, {
                    icon: MessageBox.Icon.ERROR,
                    title:"Error",
                    actions: [MessageBox.Action.OK]
                });
            },

            onLeft2CellClick : function(oControlEvent)
            {
                var rowIdx = ""+oControlEvent.getParameters().rowIndex;
                var oModel = this.getView().getModel();
                var DAT = oModel.getProperty("/app/et_my_rp");
   
                var that = this;
                var oView = this.getView();
                var objTbl = ["et_my_rp", "et_my_ri"];
            
                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                oData.rpno = DAT[rowIdx].rpno;
                oModel.setProperty("/app/click_rpno", oData.rpno);
                library.getRfcData(that, oView, "Z_OTC_IF6501", objTbl, oData, false);
            },

            

            onRightEmailButton : function(oEvent)
            {
                var oModel = this.getView().getModel();
                var rowIdx = (""+oEvent.getSource().getBindingContext()).replace("/app/et_my_ri/", "");

                var et_my_ri = [];
                et_my_ri = oModel.getProperty('/app/et_my_ri');
                if(et_my_ri[rowIdx].rpno == null || et_my_ri[rowIdx].upd == "")
                {
                    return false;
                }

                var that = this;
                var oView = this.getView();

                MessageBox.confirm("sample메일을 발송하시겠습니까?", 
                    {
                    actions: ["발송", MessageBox.Action.CLOSE],
                    emphasizedAction: "Manage Products",
                    onClose: function (sAction) 
                    {
                        if(sAction != "CLOSE")
                        {
                            var it_my_ri = [];
                            it_my_ri[0] = et_my_ri[rowIdx];

                            var objTbl = [];
        
                            // Input Data 설정
                            var oData = {};
                            oData.rino = it_my_ri[0].rino;

                            library.getRfcData(that, oView, "Z_OTC_IF6506", objTbl, oData, false);
                        }
                    }
                });                
            },

            //편집/삭제
            onRightDelButton : function(oEvent)
            {
                var oModel = this.getView().getModel();
                var rowIdx = (""+oEvent.getSource().getBindingContext()).replace("/app/et_my_ri/", "");

                var et_my_ri = [];
                et_my_ri = oModel.getProperty('/app/et_my_ri');
                if(et_my_ri[rowIdx].rpno == null || et_my_ri[rowIdx].upd == "")
                {
                    return false;
                }

                var that = this;
                var oView = this.getView();

                MessageBox.warning("선택한 항목을 삭제하시겠습니까?", 
                    {
                    actions: ["삭제", MessageBox.Action.CLOSE],
                    emphasizedAction: "Manage Products",
                    onClose: function (sAction) 
                    {
                        if(sAction != "CLOSE")
                        {
                            var it_my_ri = [];
                            it_my_ri[0] = et_my_ri[rowIdx];

                            var objTbl = ["et_my_ri"];
        
                            // Input Data 설정
                            var oData = {};
                            oData.ptype = "D";
                            //oData.rpno = et_my_ri[rowIdx].rpno;
                            oData.it_my_ri = it_my_ri;
                            
                            var et_my_rp = oModel.getProperty("/app/et_my_rp");
                            var rpno = "";
                            for(var i=0; i<et_my_rp.length; i++)
                            {
                                if(et_my_rp[i].rpnm.indexOf("▶") > -1)
                                {
                                    rpno = et_my_rp[i].rpno;
                                }
                            }
                            oData.rpno = rpno;

                            library.getRfcData(that, oView, "Z_OTC_IF6501", objTbl, oData, false);
                        }
                    }
                });
            },

            onSpreadsheetExport: function (oEvent) {
                var oTable = this.getView().byId('right2');
                var aCols = [];
                var aColumn = oTable.getAggregation('columns');

                if (typeof aColumn !== "undefined" && aColumn !== null) {
                    for(var i=0; i<aColumn.length; i++) 
                    {
                        alert("i==========>"+i+",   "+aColumn[i]+":::::::"+aColumn[i].getCustomData()[0]);
                        if(aColumn[i].getProperty('name') == 'x' || aColumn[i].getCustomData()[0] == "undefined")
                        {
                            continue;
                        }

                        aCols.push({
                            label: aColumn[i].getAggregation('label').getProperty('text'),
//			    			type: sap.ui.model.odata.v2.ODataModel.EdmType.String,
                            property: aColumn[i].getCustomData()[0].getProperty('value'),
//			    			scale: 0
                            width: aColumn[i].getWidth()
                        });				
                    }
                    var oTableData = oTable.getBinding('rows').oList;
                    var oSettings = {
                        workbook: { columns: aCols },
                        dataSource: oTableData,
//						fileName: 'Table export sample.xlsx',
						worker: false
                    };
                    var oSheet = new Spreadsheet(oSettings);
                    oSheet.build().then( function() {
                        MessageToast.show('Spreadsheet export has finished');
                    });
                }
            }
        });
    });
