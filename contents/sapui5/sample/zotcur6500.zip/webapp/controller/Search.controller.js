sap.ui.define([
    "sap/ui/core/Core",
	"sap/ui/core/library",
    "control/library",
    "./PopController",
    "sap/ui/export/Spreadsheet",
    "sap/m/MessageBox"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Core, CoreLibrary, library, Controller, Spreadsheet, MessageBox) {
        "use strict";

        return Controller.extend("zotcur6500.controller.My", {
            onInit: function () {
                this.oOwnerComponent = this.getOwnerComponent();
                this.oRouter = this.oOwnerComponent.getRouter();
                this.oRouter.attachRouteMatched(this.onRouteMatched, this);
                this.oRouter.attachBeforeRouteMatched(this.onBeforeRouteMatched, this);
            },

            onBeforeRouteMatched: function(oEvent) {
                var oModel = this.oOwnerComponent.getModel(),
                	sLayout = oEvent.getParameters().arguments.layout,
                	oNextUIState;

            },

            onRouteMatched: function (oEvent) {
                var sRouteName = oEvent.getParameter("name"),
                    oArguments = oEvent.getParameter("arguments");

                // Save the current route name
                this.currentRouteName = sRouteName;
                this.currentProduct = oArguments.product;
            },

            onSearch:function(oEvent){
                var that = this;
                var oView = this.getView();
                var oModel = this.getView().getModel();

                var objTbl = ["et_list"];
                var range = this.byId("range").getSelectedIndex();
                
                var rangeValue = "";
                switch(range)
                {
                    case 0: //최근 1개월
                        rangeValue = "01";
                    break;
                    case 1: //최근 3개월
                        rangeValue = "03";
                    break;
                    case 2: //최근 6개월
                        rangeValue = "06";
                    break;
                    case 3: //최근 1년
                        rangeValue = "12";
                    break;
                    case 4: //전체
                        rangeValue = "00";
                    break;
                }

                // Input Data 설정
                var oData = {};
                oData.keyword = this.byId("keyword").getValue();
                oData.range = rangeValue;

                library.getRfcData(that, oView, "Z_OTC_IF6504", objTbl, oData, false);
            },

            onRefresh: function (oEvent) {
                var oTable = this.byId('search');
                var aColumns = oTable.getColumns();
                
                oTable.getBinding().sort(null);
                for (var i = 0; i < aColumns.length; i++) {
                    aColumns[i].setSorted(false);
                    oTable.filter(aColumns[i], null);
                }

                this.onSearch();
            },

            onCallback: function(oModel, RFC_CD, ptype)
            {
                switch(RFC_CD)
                {
                    case "Z_OTC_IF6504":
                        //MessageBox.success("저장 되었습니다.");
                        var oModel = this.getView().getModel();
                        var et_list = oModel.getProperty("/app/et_list");
                        for(var i=0; i<et_list.length; i++)
                        {
                            et_list[i].no = i+1;
                            var execyl = et_list[i].execyl;

                            switch(execyl)
                            {
                                case "M":
                                    //et_list[i].execyltxt = "매월 "+et_list[i].zday+"일 "+ et_list[i].exetim+"시";
                                    et_list[i].execyltxt = "월 1회 구독하기";
                                break;
                                case "W":
                                    //var week = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"];
                                    //var wknumTxt = week[et_list[i].wknum];
                                    //et_list[i].execyltxt = "매주 "+wknumTxt+" "+ et_list[i].exetim+"시";
                                    et_list[i].execyltxt = "주 1회 구독하기";
                                break;
                                case "D":
                                    //et_list[i].execyltxt = "매일 "+et_list[i].exetim+"시";
                                    et_list[i].execyltxt = "일 1회 구독하기";
                                break;
                                default:
                                    et_list[i].execyltxt = "";
                            }

                            et_list[i].circleDis=true;
                            if(et_list[i].stat == "S") et_list[i].icon = "sap-icon://complete";
                            else if(et_list[i].stat == "H") et_list[i].icon = "sap-icon://stop";
                            else et_list[i].circleDis = false;
                        }
                        oModel.setProperty("/app/et_list", et_list);
                        break;
                    case "Z_OTC_IF6506":
                        MessageBox.success("발송 되었습니다.");
                        break;
                }
            },

            onRightEmailButton : function(oEvent)
            {
                var oModel = this.getView().getModel();
                var rowIdx = (""+oEvent.getSource().getBindingContext()).replace("/app/et_list/", "");

                var et_list = [];
                et_list = oModel.getProperty('/app/et_list');
                if(et_list[rowIdx].rpno == null || et_list[rowIdx].upd == "")
                {
                    return false;
                }

                var that = this;
                var oView = this.getView();

                MessageBox.confirm("sample메일을 발송하시겠습니까?", 
                    {
                    actions: ["발송", MessageBox.Action.CLOSE],
                    emphasizedAction: "Manage Products",
                    onClose: function (sAction) 
                    {
                        if(sAction != "CLOSE")
                        {
                            var it_ri = [];
                            it_ri[0] = et_list[rowIdx];

                            var objTbl = [];
        
                            // Input Data 설정
                            var oData = {};
                            oData.rino = it_ri[0].rino;
                            library.getRfcData(that, oView, "Z_OTC_IF6506", objTbl, oData, false);
                        }
                    }
                });                
            },
/*
            onCellClick : function(oControlEvent)
            {
                var COL_NM = oControlEvent.getParameters().columnId;

                if(COL_NM.indexOf("execyltxt") > -1)
                {
                    this.onRightUptButton(oControlEvent, "et_list");
                }
            },
*/
            onSpreadsheetExport: function (oEvent) {
                var oTable = this.getView().byId('search');
                var aCols = [];
                var aColumn = oTable.getAggregation('columns');

                if (typeof aColumn !== "undefined" && aColumn !== null) {
                    for(var i=0; i<aColumn.length; i++) 
                    {
                        if(aColumn[i].getProperty('name') == 'x')
                        {
                            continue;
                        }

                        aCols.push({
                            label: aColumn[i].getAggregation('label').getProperty('text'),
//			    			type: sap.ui.model.odata.v2.ODataModel.EdmType.String,
                            property: aColumn[i].getCustomData()[0].getProperty('value'),
//			    			scale: 0
                            width: aColumn[i].getWidth()
                        });				
                    }
                    var oTableData = oTable.getBinding('rows').oList;
                    var oSettings = {
                        workbook: { columns: aCols },
                        dataSource: oTableData,
//						fileName: 'Table export sample.xlsx',
						worker: false
                    };
                    var oSheet = new Spreadsheet(oSettings);
                    oSheet.build().then( function() {
                        MessageToast.show('Spreadsheet export has finished');
                    });
                }
            }
        });
    });
