sap.ui.define([
	"sap/ui/core/Core",
	"sap/ui/core/library",
    "control/library",
    "./PopController",
    "sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
    "sap/ui/table/Column",
	"sap/m/Label",
    'sap/ui/model/BindingMode',
    "sap/m/Text",
    "sap/ui/export/Spreadsheet",
    "../model/Formatter"
], 
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Core, CoreLibrary, library, Controller, ODataModel, MessageBox, MessageToast, Column, Label, BindingMode, Text, Spreadsheet, Formatter) {

        "use strict";

        return Controller.extend("zotcur6500.controller.Risk", {
            Formatter:Formatter,
            onInit: function () {
                this.oOwnerComponent = this.getOwnerComponent();
                this.oRouter = this.oOwnerComponent.getRouter();
                this.oRouter.attachRouteMatched(this.onRouteMatched, this);
                this.oRouter.attachBeforeRouteMatched(this.onBeforeRouteMatched, this);
            },

            onBeforeRouteMatched: function(oEvent) {
                var oModel = this.oOwnerComponent.getModel(),
                	sLayout = oEvent.getParameters().arguments.layout,
                    oNextUIState;
                
            },

            onRouteMatched: function (oEvent) {
                var sRouteName = oEvent.getParameter("name"),
                    oArguments = oEvent.getParameter("arguments");

                // Save the current route name
                this.currentRouteName = sRouteName;
                this.currentProduct = oArguments.product;
            },

            onLeft2CellClick : function(oControlEvent)
            {
                var rowIdx = ""+oControlEvent.getParameters().rowIndex;
                var oModel = this.getView().getModel();
                var DAT = oModel.getProperty("/app/et_rp");
   
                var that = this;
                var oView = this.getView();
                var objTbl = ["et_rp", "et_ri"];
            
                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                oData.rpno = DAT[rowIdx].rpno;
                oData.bizno = oModel.getProperty('/app/risk_bizno');;
                oModel.setProperty("/app/click_rpno", oData.rpno);
                library.getRfcData(that, oView, "Z_OTC_IF6502", objTbl, oData, false);
            },

            onCallback: function(oModel, RFC_CD, ptype)
            {
                switch(RFC_CD)
                {
                    case "Z_OTC_IF6501":
                        if(ptype == "R")
                        {
                        }
                        break;
                    case "Z_OTC_IF6502":
                        library.fnSetRiskTable(oModel);
                        break;
                    case "Z_OTC_IF6506":
                        MessageBox.success("발송 되었습니다.");
                        break;
                }
            },

            makeOdataFilter:function(oFilter) {
                var mFilter = [];
                
                for(var sKey in oFilter) {
                    var oVal = oFilter[sKey];
    
                    if(!(oVal instanceof Object) || oVal instanceof Date) {
                        if(oVal) {
                            mFilter.push(new sap.ui.model.Filter({
                                path: sKey,
                                operator: sap.ui.model.FilterOperator.EQ,
                                value1: oVal
                            }));
                        }
                    // Array로 입력된 Tokens값 처리
                    } else if(Array.isArray(oVal)) {
                        if(oVal.length > 0) {
                            for (var sArrayKey in oVal) {
                                var oFilterVal = oVal[sArrayKey];
        
                                mFilter.push(new sap.ui.model.Filter({
                                    path: sKey,
                                    operator: oFilterVal.operation,
                                    value1: oFilterVal.value1,
                                    value2: oFilterVal.value2
                                }));
                            }
                        }
                        
                     } else {
                        mFilter.push(new sap.ui.model.Filter({
                            path: sKey,
                            operator: sap.ui.model.FilterOperator.BT,
                            value1: oVal.value1,
                            value2: oVal.value2
                        }));
                    }
                }
    
                return mFilter;
            },

            fnDisplayError : function(oEvent) {
                this.getView().setBusy(false);
                
                var oMessage = JSON.parse(oEvent.responseText);
                var sMessage = '';
                if (oMessage.error.innererror.hasOwnProperty('errordetails')) {
                    oMessage.error.innererror.errordetails.forEach(function(oItem){
                        sMessage += oItem.message+'\n';
                    });
                } else {
                    sMessage += oMessage.error.innererror.Error_Resolution.SAP_Transaction;
                }
    
                
                MessageBox.show(sMessage, {
                    icon: MessageBox.Icon.ERROR,
                    title:"Error",
                    actions: [MessageBox.Action.OK]
                });
            },

            onRightEmailButton : function(oEvent)
            {
                var oModel = this.getView().getModel();
                var rowIdx = (""+oEvent.getSource().getBindingContext()).replace("/app/et_ri/", "");

                var et_ri = [];
                et_ri = oModel.getProperty('/app/et_ri');
                if(et_ri[rowIdx].rpno == null || et_ri[rowIdx].upd == "")
                {
                    return false;
                }

                var that = this;
                var oView = this.getView();

                MessageBox.confirm("sample메일을 발송하시겠습니까?", 
                    {
                    actions: ["발송", MessageBox.Action.CLOSE],
                    emphasizedAction: "Manage Products",
                    onClose: function (sAction) 
                    {
                        if(sAction != "CLOSE")
                        {
                            var it_ri = [];
                            it_ri[0] = et_ri[rowIdx];

                            var objTbl = [];
        
                            // Input Data 설정
                            var oData = {};
                            oData.rino = it_ri[0].rino;
                            library.getRfcData(that, oView, "Z_OTC_IF6506", objTbl, oData, false);
                        }
                    }
                });                
            },
            onBeforeExport: function (oEvt) {

                alert("호출");
                var mExcelSettings = oEvt.getParameter("exportSettings");

                // Disable Worker as Mockserver is used in Demokit sample
                mExcelSettings.worker = false;
            },

            formatRowHighlight: function (oValue) {
                // Your logic for rowHighlight goes here
                if (oValue < 2) {
                    return "Error";
                } else if (oValue < 3) {
                    return "Warning";
                } else if (oValue < 5) {
                    return "None";
                }
                return "Success";
            },

            columnFactory : function(sId, oContext) {
                var that = this;
                var oModel = this.getView().getModel();
                var sColumnName = oContext.sPath.replace('/app/columns/', '');
                var sColumnWidth = "8rem";
 
                return new Column(sId, {
                    visible: true,
                    sortProperty: true,
                    filterProperty: true,
                    width: sColumnWidth,
                    label: new Label({text: sColumnName}),
                    hAlign: "Begin",
                    template: new Text({text: {path: sColumnName}, wrapping: false})
                });
            },

            onSpreadsheetExport: function (oEvent) {
                var oTable = this.getView().byId('riskTable');
                var aCols = [];
                var aColumn = oTable.getAggregation('columns');

                if (typeof aColumn !== "undefined" && aColumn !== null) {
                    for(var i=0; i<aColumn.length; i++) {
                        if(aColumn[i].getProperty('name') == 'x')
                        {
                            continue;
                        }
                        
                        aCols.push({
                            label: aColumn[i].getAggregation('label').getProperty('text'),
//			    			type: sap.ui.model.odata.v2.ODataModel.EdmType.String,
                            property: aColumn[i].getCustomData()[0].getProperty('value'),
//			    			scale: 0
                            width: aColumn[i].getWidth()
                        });				
                    }
                    var oTableData = oTable.getBinding('rows').oList;
                    var oSettings = {
                        workbook: { columns: aCols },
                        dataSource: oTableData,
//						fileName: 'Table export sample.xlsx',
						worker: false
                    };
                    var oSheet = new Spreadsheet(oSettings);
                    oSheet.build().then( function() {
                        MessageToast.show('Spreadsheet export has finished');
                    });
                }
            }

            ,

            resetGroupDialog: function(oEvent) {
                this.groupReset =  true;
            },

            getViewSettingsDialog: function (sDialogFragmentName) {
                var pDialog = this._mViewSettingsDialogs[sDialogFragmentName];

                if (!pDialog) {
                    pDialog = Fragment.load({
                        id: this.getView().getId(),
                        name: sDialogFragmentName,
                        controller: this
                    }).then(function (oDialog) {
                        if (Device.system.desktop) {
                            oDialog.addStyleClass("sapUiSizeCompact");
                        }
                        return oDialog;
                    });
                    this._mViewSettingsDialogs[sDialogFragmentName] = pDialog;
                }
                return pDialog;
            },

            handleSortButtonPressed: function () {
                this.getViewSettingsDialog("zotcur6500.fragment.SortDialog")
                    .then(function (oViewSettingsDialog) {
                        oViewSettingsDialog.open();
                    });
            },

            handleFilterButtonPressed: function () {
                this.getViewSettingsDialog("zotcur6500.fragment.FilterDialog")
                    .then(function (oViewSettingsDialog) {
                        oViewSettingsDialog.open();
                    });
            },

            handleGroupButtonPressed: function () {
                this.getViewSettingsDialog("zotcur6500.fragment.GroupDialog")
                    .then(function (oViewSettingsDialog) {
                        oViewSettingsDialog.open();
                    });
            },

            handleSortDialogConfirm: function (oEvent) {
                var oTable = this.byId("idProductsTable"),
                    mParams = oEvent.getParameters(),
                    oBinding = oTable.getBinding("items"),
                    sPath,
                    bDescending,
                    aSorters = [];

                sPath = mParams.sortItem.getKey();
                bDescending = mParams.sortDescending;
                aSorters.push(new Sorter(sPath, bDescending));

                // apply the selected sort and group settings
                oBinding.sort(aSorters);
            },

            handleFilterDialogConfirm: function (oEvent) {
                var oTable = this.byId("idProductsTable"),
                    mParams = oEvent.getParameters(),
                    oBinding = oTable.getBinding("items"),
                    aFilters = [];

                mParams.filterItems.forEach(function(oItem) {
                    var aSplit = oItem.getKey().split("___"),
                        sPath = aSplit[0],
                        sOperator = aSplit[1],
                        sValue1 = aSplit[2],
                        sValue2 = aSplit[3],
                        oFilter = new Filter(sPath, sOperator, sValue1, sValue2);
                    aFilters.push(oFilter);
                });

                // apply filter settings
                oBinding.filter(aFilters);

                // update filter bar
                this.byId("vsdFilterBar").setVisible(aFilters.length > 0);
                this.byId("vsdFilterLabel").setText(mParams.filterString);
            },

            handleGroupDialogConfirm: function (oEvent) {
                var oTable = this.byId("idProductsTable"),
                    mParams = oEvent.getParameters(),
                    oBinding = oTable.getBinding("items"),
                    sPath,
                    bDescending,
                    vGroup,
                    aGroups = [];

                if (mParams.groupItem) {
                    sPath = mParams.groupItem.getKey();
                    bDescending = mParams.groupDescending;
                    vGroup = this.mGroupFunctions[sPath];
                    aGroups.push(new Sorter(sPath, bDescending, vGroup));
                    // apply the selected group settings
                    oBinding.sort(aGroups);
                } else if (this.groupReset) {
                    oBinding.sort();
                    this.groupReset = false;
                }
            },

            onToggleContextMenu: function (oEvent) {
                var oToggleButton = oEvent.getSource();
                if (oEvent.getParameter("pressed")) {
                    oToggleButton.setTooltip("Disable Custom Context Menu");
                    this.byId("idProductsTable").setContextMenu(new Menu({
                        items: [
                            new MenuItem({text: "{Name}"}),
                            new MenuItem({text: "{ProductId}"})
                        ]
                    }));
                } else {
                    oToggleButton.setTooltip("Enable Custom Context Menu");
                    this.byId("idProductsTable").destroyContextMenu();
                }
            },

            onCellClick : function(oControlEvent)
            {
                var COL_NM = oControlEvent.getParameters().columnId;

                if(COL_NM.indexOf("execyltxt") > -1)
                {
                    this.onRightUptButton(oControlEvent, "et_ri");
                }
            },

            onLinkSap : function(oControlEvent)
            {
                var oModel = this.getView().getModel();
                var rowIdx = ""+oControlEvent.getParameters().rowIndex;
         
                var arr = [];
                arr = oModel.getProperty("/app/et_ri");
                var zzz = arr[0].zlink;
                alert(zzz);
            }
        });
    });
