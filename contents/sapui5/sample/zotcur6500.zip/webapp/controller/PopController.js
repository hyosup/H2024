sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "control/library",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
    "sap/ui/core/Fragment",
    "sap/ui/Device"
	], function (Controller, library, ODataModel, JSONModel, MessageBox, Fragment, Device) {
		"use strict";

        var POP_CLICK = "pop_detail";
        var POP_DET_TITLE = "구독NO : ";
		return Controller.extend("zotcur6500.controller.BaseController", {
			/**
			 * Convenience method for accessing the router.
			 * @public
			 * @returns {sap.ui.core.routing.Router} the router for this component
			 */
			getRouter : function () {
				return sap.ui.core.UIComponent.getRouterFor(this);
			},

			/**
			 * Convenience method for getting the view model by name.
			 * @public
			 * @param {string} [sName] the model name
			 * @returns {sap.ui.model.Model} the model instance
			 */
			getModel : function (sName) {
				return this.getView().getModel(sName);
			},

			/**
			 * Convenience method for setting the view model.
			 * @public
			 * @param {sap.ui.model.Model} oModel the model instance
			 * @param {string} sName the model name
			 * @returns {sap.ui.mvc.View} the view instance
			 */
			setModel : function (oModel, sName) {
				return this.getView().setModel(oModel, sName);
			},

			/**
			 * Getter for the resource bundle.
			 * @public
			 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
			 */
			getResourceBundle : function () {
				return this.getOwnerComponent().getModel("i18n").getResourceBundle();
			},

            getRfcData(that, oView, RFC_CD, objTbl, oData, warningTF)
            {
                var oDeviceModel = new JSONModel(Device);
                oDeviceModel.setDefaultBindingMode("OneWay");
                this.getView().setModel(oDeviceModel, "device");

                var oModelR = sap.ui.getCore().getModel('ROOT');
                oView.setModel(oModelR);
                oView.bindObject({path: '/'+'app'});    //View Name


                var oModel = this.getView().getModel();
                var oModelO = sap.ui.getCore().getModel('ODAT');
                var oFilter = {};// gateway로 보낼 조회조건
                var sEntity = RFC_CD;
                var sEntitySet = '/' + sEntity + 'Set';
               
                oData.login = oModel.getProperty('/app/login');
                // oFilter.input = JSON.stringify(oModel.getProperty('/app/login'));
                oFilter.input = JSON.stringify(oData);
                that.getView().setBusy(true);

                oModelO.read(sEntitySet, {  //'/Z_OTC_IF6500Set'
                    async : true,
                    filters : library.makeOdataFilter(oFilter),
                    success : function(oDataI, response) { // 메세지를 받아오기 위해 response 추가
                        var aReturnData = [];
                        //that.getView().setBusy(false);

                        // 결과
                        var ret = false;                        
                        if(oDataI.results.length > 0 && oDataI.results[0].output) 
                        {
                            // Return Data 처리
                            aReturnData = JSON.parse(oDataI.results[0].output);

                            if (aReturnData.es_return) {
                                var sIcon = MessageBox.Icon.NONE;
                                var sReturnType = aReturnData.es_return.mtype;
                                //if (sReturnType != 'S') {
                                if (warningTF) {
                                    switch (sReturnType) {
                                        case 'S':   //성공
                                            sIcon = MessageBox.Icon.SUCCESS;
                                            break;
                                        case 'E':   //오류
                                            sIcon = MessageBox.Icon.ERROR;
                                            break;
                                        case 'W':   //경고
                                            sIcon = MessageBox.Icon.WARNING;
                                            break;
                                        case 'I':   //정보
                                            sIcon = MessageBox.Icon.INFORMATION;
                                            break;
                                        case 'A':   //중단
                                            sIcon = MessageBox.Icon.ERROR;
                                            break;
                                        default:
                                            sIcon = MessageBox.Icon.NONE;
                                            break;
                                    }

                                    MessageBox.show(aReturnData.es_return.message, {
                                        icon: sIcon,
                                        title: sReturnType,
                                        actions: sReturnType != "A" ? [MessageBox.Action.OK] : [MessageBox.Action.ABORT],
                                        onClose: function (oAction) { 
                                            if(oAction === 'OK') {
                                                /** */
                                            }
                                        }
                                    });
                                }    
                            }

                            for(var i=0; i<objTbl.length; i++)
                            {
                                var tblNm = objTbl[i];
                                var RFC_DATA = [];
                                RFC_DATA = eval("aReturnData."+tblNm);
                             
                                if(RFC_CD == "Z_OTC_IF6503")
                                {
                                    oModel.setProperty('/app/pop_'+tblNm, RFC_DATA); //
                                }
                                else
                                {
                                    oModel.setProperty('/app/'+tblNm, RFC_DATA); //
                                }
                            }

                            ret = true;
                        }

                        that.getView().setBusy(false);
                        that.onCallbackPop(oModel, RFC_CD, oData.ptype);
                    },
                    error : that.fnDisplayError.bind(that)
                });
            },
			
            fnDisplayError : function(oEvent) {
                this.getView().setBusy(false);
                
                var oMessage = JSON.parse(oEvent.responseText);
                var sMessage = '';
                if (oMessage.error.innererror.hasOwnProperty('errordetails')) {
                    oMessage.error.innererror.errordetails.forEach(function(oItem){
                        sMessage += oItem.message+'\n';
                    });
                } else {
                    sMessage += oMessage.error.innererror.Error_Resolution.SAP_Transaction;
                }
    
                
                MessageBox.show(sMessage, {
                    icon: MessageBox.Icon.ERROR,
                    title:"Error",
                    actions: [MessageBox.Action.OK]
                });
            },

            onCallbackPop: function(oModel, RFC_CD, ptype)
            {
                switch(RFC_CD)
                {
                    case "Z_OTC_IF6503":
                        if(ptype == "R" || ptype == "U")
                        {
                            if(ptype == "U")
                            {
                                MessageBox.success("저장 되었습니다.");
                            }
                            var oView = this.getView();
                            var oModel = this.getView().getModel();

                            var ET_RI_DTL = [];
                            ET_RI_DTL = oModel.getProperty("/app/pop_et_ri_dtl");

                            //상세설명 -start
                            var text = "";
                            var zdesc = "";
                            var blank = "";
                           
                            for(var i=0; i<ET_RI_DTL.length; i++)
                            {
                                if(ET_RI_DTL[i].xbold == "X")
                                {
                                    zdesc = "<strong>"+ET_RI_DTL[i].zdesc+"</strong>";

                                    if(i>0) zdesc = "<br/>"+zdesc;
                                }
                                else
                                {
                                    zdesc = ET_RI_DTL[i].zdesc;
                                }

                                blank = "";
                                for(var j=0; j<ET_RI_DTL[i].shift; j++)
                                {
                                    blank+="&nbsp;"
                                }

                                text += blank+""+zdesc+"<br/>";

                            }
                            text+="<br/><strong>* 점검 Report</strong><br/>";
/*
                            var et_my_ri = oModel.getProperty("/app/my_ri");

                            text+="<br/><strong>* 점검 Report</strong><br/>";

                            var link = et_my_ri.zlink;
                            //link = link.replace("||", "\|\|");
                            link = link.replace("||ALL", " ||ALL");
                            //text+="&nbsp;<a href='"+et_my_ri.zlink+"' target='_blank'>"+et_my_ri.scrn+"</a><br/>";
                            text+="&nbsp;<a href='"+link+"' target='_blank'>"+et_my_ri.scrn+"</a><br/>";

                            //text+="&nbsp;"+et_my_ri.zlink+"<br/>";
                            //text+="&nbsp;"+link+"<br/>";
*/

                            oModel.setProperty("/app/HTML", text);
                            //상세설명 -end

                            if (!this._pDialog) {
                                this._pDialog = Fragment.load({
                                    id: oView.getId(),
                                    name: "zotcur6500.fragment.InfoPop",
                                    //draggable: true,
                                    //outerHeight : "900px",
                                    //controller: "zotcur6500.controller.InfoPop"
                                    controller:this
                                }).then(function(oDialog){
                                    oView.addDependent(oDialog);
                                    return oDialog;
                                });
                            }


                            //et_sub.EXECYL 

                            var RFC_ET_SUB = oModel.getProperty("/app/pop_et_sub");
                            var RFC_ET_RI  = oModel.getProperty("/app/pop_et_ri");
                            var pop_subno = oModel.getProperty("/app/pop_subno");

                            if(ptype == "U")
                            {
                                for(var i=0; i<RFC_ET_SUB.length; i++)
                                {
                                    if((""+RFC_ET_SUB[i].rmk).indexOf("▶") > -1)
                                    {
                                        pop_subno = RFC_ET_SUB[i].subno;
                                        oModel.setProperty("/app/pop_subno", pop_subno);
                                        break;
                                    }
                                }
                            }
                            
                            var pop_it_sub = [{
                                subno:pop_subno
                                ,rino:''
                                ,email:''
                                ,sub_logid:''
                                ,xmndty:''
                                ,xmndty_tf:false
                                ,stat:''
                                ,stat_tf:false
                                ,lvorm:''
                                ,exetim:'0'
                                ,wknum:'0'
                                ,zday:''
                                ,iesign:''
                                ,value:''
                                ,rmk:''
                                ,selectCol:''
                                ,selectKey:''
                                ,icon:''
                                ,circleDis:''
                                ,unt:''
                                ,erdat:''
                                ,erzet:''
                                ,ernam:''
                                ,aedat:''
                                ,aezet:''
                                ,aenam:''
                            }];

                            var SELECT_ITEM = [{name:"", key:""}];
                            if(pop_subno != '')  // -1보다 큰건 팝업의 좌측 테이블 클릭시들어온다.
                            {
                                oModel.setProperty("/app/click_title", POP_DET_TITLE+pop_subno);
                                var LEFT_C = -1;
                                for(var i=0; i<RFC_ET_SUB.length; i++)
                                {
                                    if(RFC_ET_SUB[i].subno == pop_subno)
                                    {
                                        LEFT_C = i;
                                        break;
                                    }
                                }


                                pop_it_sub[0].rino      = RFC_ET_SUB[LEFT_C].rino;
                                pop_it_sub[0].subid     = RFC_ET_SUB[LEFT_C].subid;
                                pop_it_sub[0].email     = RFC_ET_SUB[LEFT_C].email;
                                pop_it_sub[0].xmndty    = RFC_ET_SUB[LEFT_C].xmndty;
                                pop_it_sub[0].xmndty_tf = false;
                                pop_it_sub[0].stat      = RFC_ET_SUB[LEFT_C].stat;
                                pop_it_sub[0].stat_tf   = false;
                                pop_it_sub[0].lvorm     = RFC_ET_SUB[LEFT_C].lvorm;
                                pop_it_sub[0].unt       = RFC_ET_RI[0].unt;
                                
                                var exetim = RFC_ET_SUB[LEFT_C].exetim;
                                if(exetim == '') exetim = 0;
                                pop_it_sub[0].exetim    = exetim;

                                var wknum = RFC_ET_SUB[LEFT_C].wknum;
                                if(wknum == '') wknum = 0;
                                pop_it_sub[0].wknum     = wknum;

                                var zday = RFC_ET_SUB[LEFT_C].zday;
                                if(zday == 0) zday = '';
                                pop_it_sub[0].zday      = zday;

                                pop_it_sub[0].iesign    = RFC_ET_SUB[LEFT_C].iesign;
                                pop_it_sub[0].value     = RFC_ET_SUB[LEFT_C].value;
                                pop_it_sub[0].rmk       = RFC_ET_SUB[LEFT_C].rmk;
                                pop_it_sub[0].circleDis = false;
                                pop_it_sub[0].icon      = "";

                                pop_it_sub[0].erdat     = RFC_ET_SUB[LEFT_C].erdat;
                                pop_it_sub[0].erzet     = RFC_ET_SUB[LEFT_C].erzet;
                                pop_it_sub[0].ernam     = RFC_ET_SUB[LEFT_C].ernam;
                                pop_it_sub[0].aedat     = RFC_ET_SUB[LEFT_C].aedat;
                                pop_it_sub[0].aezet     = RFC_ET_SUB[LEFT_C].aezet;
                                pop_it_sub[0].aenam     = RFC_ET_SUB[LEFT_C].aenam;

                                var EXECYL = RFC_ET_RI[0].execyl;

                                if(EXECYL == undefined || EXECYL == "D")
                                {
                                    SELECT_ITEM = [];
                                    oModel.setProperty("/app/select", SELECT_ITEM);
                                    oModel.setProperty("/app/selectView", false);
                                    oModel.setProperty("/app/execyl", "매일");
                                    pop_it_sub[0].selectCol = '';
                                    pop_it_sub[0].selectKey = '';
                                }
                                else if(EXECYL == "W")
                                {
                                    var week = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"];
                                    SELECT_ITEM = [];
                                    for(var i=0; i<week.length; i++)
                                    {
                                        SELECT_ITEM.push({name:week[i], key:(i+1)});
                                    }

                                    oModel.setProperty("/app/execyl", "매주");
                                    oModel.setProperty("/app/select", SELECT_ITEM);
                                    oModel.setProperty("/app/selectView", true);
                                    pop_it_sub[0].selectCol = 'wknum';
                                    pop_it_sub[0].selectKey = RFC_ET_SUB[LEFT_C].wknum;
                                }
                                else if(EXECYL == "M")
                                {
                                    SELECT_ITEM = [];
                                    for(var i=0; i<31; i++)
                                    {
                                        SELECT_ITEM.push({name:(i+1)+'일', key:(i+1)});
                                    }

                                    oModel.setProperty("/app/select", SELECT_ITEM);
                                    oModel.setProperty("/app/execyl", "매월");
                                    oModel.setProperty("/app/selectView", true);
                                    pop_it_sub[0].selectCol = 'zday';
                                    pop_it_sub[0].selectKey = RFC_ET_SUB[LEFT_C].zday;
                                 }

                                //필수 구독-start
                                if(RFC_ET_SUB[LEFT_C].xmndty == "X")
                                {
                                    pop_it_sub[0].xmndty_tf = true;
                                }
                                else
                                {
                                    pop_it_sub[0].xmndty_tf = false;
                                }
                                //필수 구독-end

                                //구독조건-start
                                

                                //구독조건 비율(동적)
                                var ridata_nm = RFC_ET_RI[0].ridata;
                                ridata_nm = ridata_nm.replaceAll("|N", "\r\n");
                                oModel.setProperty("/app/ridata_nm", ridata_nm);

                                //등호 만들기-st
                                var signs =RFC_ET_RI[0].iesigns;
                                var sign = signs.split(",");
    
                                SELECT_ITEM = [];
                                for(var i=0; i<sign.length; i++)
                                {
                                    SELECT_ITEM.push({name:sign[i], key:sign[i]});
                                }
                                oModel.setProperty("/app/iesigns", SELECT_ITEM);
                                //등호만들기 -ed

                                //구독조건-end

                                var et_var_field = oModel.getProperty("/app/pop_et_var_field");
                                var et_var_data  = oModel.getProperty("/app/pop_et_var_data");
                                var fieldrmk = "";
                                for(var i=0; i<et_var_field.length; i++)
                                {
                                    fieldrmk = "";

                                    if(et_var_field[i].xmndty == "X")
                                    {
                                        fieldrmk = "필수";
                                    }
                                    else
                                    {
                                        fieldrmk = "공백은 전체대상";
                                    }

                                    if(et_var_field[i].xmulti == "X")
                                    {
                                        fieldrmk += ", 다중선택";
                                    }
                                    et_var_field[i].fieldrmk = fieldrmk;

                                    var fieldid = et_var_field[i].fieldid;
                                    for(var j=0; j<et_var_data.length; j++)
                                    {
                                        if(et_var_data[j].fieldid == fieldid)
                                        {
                                            et_var_field[i].fielddata = et_var_data[j].fielddata;
                                            break;
                                        }
                                    }
                                }
                                
                                /**
                                 * Search Help 관련 Infomation Object 생성
                                 */
                                if (Array.isArray(et_var_field) && et_var_field.length > 0) {
                                    for (var x in et_var_field) {
                                        if (et_var_field[x].shelp !== '' && et_var_field[x].fieldid !== '') 
                                        {
                                            et_var_field[x].contents = {
                                                shlpname : et_var_field[x].shelp,
                                                keys : et_var_field[x].fieldid.toLowerCase(),
                                                texts : '',
                                                xmulti: et_var_field[x].xmulti,
                                                blazy: et_var_field[x].shelplist
                                            }    
                                        }
                                    }
                                }
                                
                                oModel.setProperty("/app/pop_et_var_field", et_var_field);

                                //보류-start
                                if(RFC_ET_SUB[LEFT_C].stat == "H")
                                {
                                    pop_it_sub[0].stat_tf = true;
                                }
                                else
                                {
                                    pop_it_sub[0].stat_tf = false
                                }
                                //보류-end

                                //비고-st
                                var subRmk = RFC_ET_SUB[LEFT_C].rmk;
                                subRmk = subRmk.replace("▶", "");
                                pop_it_sub[0].rmk = subRmk;
                                //비고-ed
                            }
                            //else if(oModel.getProperty("/app/risk_bizno").indexOf("BIZ") > -1 && RFC_ET_SUB.length == 0)
                            else
                            {
                                LEFT_C = 0;

                                pop_it_sub[0].rino      = RFC_ET_RI[LEFT_C].rino;
                                pop_it_sub[0].email     = RFC_ET_RI[LEFT_C].email;
                                pop_it_sub[0].xmndty    = RFC_ET_RI[LEFT_C].xmndty;
                                pop_it_sub[0].stat      = RFC_ET_RI[LEFT_C].stat;
                                pop_it_sub[0].lvorm     = RFC_ET_RI[LEFT_C].lvorm;
                                pop_it_sub[0].unt       = RFC_ET_RI[LEFT_C].unt;


                                var exetim = RFC_ET_RI[LEFT_C].exetim;
                                if(exetim == '') exetim = 0;
                                pop_it_sub[0].exetim    = exetim;

                                var wknum = RFC_ET_RI[LEFT_C].wknum;
                                if(wknum == '') wknum = 0;
                                pop_it_sub[0].wknum     = wknum;

                                var zday = RFC_ET_RI[LEFT_C].zday;
                                if(zday == 0) zday = '';
                                pop_it_sub[0].zday      = zday;

                                pop_it_sub[0].iesign    = RFC_ET_RI[LEFT_C].iesign;
                                pop_it_sub[0].value     = RFC_ET_RI[LEFT_C].value;
                                pop_it_sub[0].rmk       = RFC_ET_RI[LEFT_C].rmk;

                                var EXECYL = RFC_ET_RI[0].execyl;
                                
                                if(EXECYL == undefined || EXECYL == "D")
                                {
                                    SELECT_ITEM = [];
                                    oModel.setProperty("/app/select", SELECT_ITEM);
                                    oModel.setProperty("/app/selectView", false);
                                    oModel.setProperty("/app/execyl", "매일");
                                    pop_it_sub[0].selectCol = '';
                                    pop_it_sub[0].selectKey = '';
                                }
                                else if(EXECYL == "W")
                                {
                                    var week = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"];
                                    SELECT_ITEM = [];
                                    for(var i=0; i<week.length; i++)
                                    {
                                        SELECT_ITEM.push({name:week[i], key:i});
                                    }

                                    oModel.setProperty("/app/execyl", "매주");
                                    oModel.setProperty("/app/select", SELECT_ITEM);
                                    oModel.setProperty("/app/selectView", true);
                                    pop_it_sub[0].selectCol = 'wknum';
                                    pop_it_sub[0].selectKey = wknum;
                                }
                                else if(EXECYL == "M")
                                {
                                    SELECT_ITEM = [];
                                    for(var i=0; i<31; i++)
                                    {
                                        SELECT_ITEM.push({name:(i+1)+'일', key:(i+1)});
                                    }

                                    oModel.setProperty("/app/select", SELECT_ITEM);
                                    oModel.setProperty("/app/execyl", "매월");
                                    oModel.setProperty("/app/selectView", true);
                                    pop_it_sub[0].selectCol = 'zday';
                                    pop_it_sub[0].selectKey = zday;
                                 }

                                //필수 구독-start
                                //pop_it_sub[0].xmndty_tf = false;
                                //필수 구독-end

                                //구독조건-start
                                

                                //구독조건 비율(동적)
                                var ridata_nm = RFC_ET_RI[0].ridata;
                                ridata_nm = ridata_nm.replaceAll("|N", "\r\n");
                                oModel.setProperty("/app/ridata_nm", ridata_nm);

                                //등호 만들기-st
                                var signs =RFC_ET_RI[0].iesigns;
                                var sign = signs.split(",");
    
                                SELECT_ITEM = [];
                                for(var i=0; i<sign.length; i++)
                                {
                                    SELECT_ITEM.push({name:sign[i], key:sign[i]});
                                }
                                oModel.setProperty("/app/iesigns", SELECT_ITEM);

                                //등호만들기 -ed

                                //구독조건-end

                                var et_var_field = oModel.getProperty("/app/pop_et_var_field");
                                var et_var_data  = oModel.getProperty("/app/pop_et_var_field");

                                var fieldrmk = "";
                                for(var i=0; i<et_var_field.length; i++)
                                {
                                    fieldrmk = "";

                                    if(et_var_field[i].xmndty == "X")
                                    {
                                        fieldrmk = "필수";
                                    }
                                    else
                                    {
                                        fieldrmk = "옵션";
                                    }

                                    if(et_var_field[i].xmulti == "X")
                                    {
                                        fieldrmk += ", 다중선택";
                                    }

                                    if(et_var_field[i].xlike == "X")
                                    {
                                        fieldrmk += ", 키워드";
                                    }

                                    et_var_field[i].fieldrmk = fieldrmk;

                                    var fieldid = et_var_field[i].fieldid;
                                    for(var j=0; j<et_var_data.length; j++)
                                    {
                                        if(et_var_data[j].fieldid == fieldid)
                                        {
                                            et_var_field[i].fielddata = et_var_data[j].fielddata;
                                            break;
                                        }
                                    }
                                }

                                /**
                                 * Search Help 관련 Infomation Object 생성
                                 */
                                if (Array.isArray(et_var_field) && et_var_field.length > 0) 
                                {
                                    for (var x in et_var_field) {
                                        if (et_var_field[x].shelp !== '' && et_var_field[x].fieldid !== '') {
                                            et_var_field[x].contents = {
                                                shlpname : et_var_field[x].shelp,
                                                keys : et_var_field[x].fieldid.toLowerCase(),
                                                texts : '',
                                                xmulti : et_var_field[x].xmulti,
                                                blazy: et_var_field[x].shelplist
                                            }    
                                        }
                                    }
                                }

                                oModel.setProperty("/app/pop_et_var_field", et_var_field);
                                oModel.setProperty("/app/pop_et_var_data", et_var_data);

                                //보류-start
                                pop_it_sub[LEFT_C].stat_tf = false

                                //보류-end

                                //비고-st
                                pop_it_sub[0].rmk = '';
                                //비고-ed
                            }


                            if(SELECT_ITEM.length == 1)
                            {
                                oModel.setProperty("/app/pop_iesign_select", false);
                                oModel.setProperty("/app/pop_value_input", false);
                            }
                            else
                            {
                                oModel.setProperty("/app/pop_iesign_select", true);
                                oModel.setProperty("/app/pop_value_input", true);
                            }

                            if(RFC_ET_SUB.length > 0)
                            {
                                for(var i=0; i<RFC_ET_SUB.length; i++)
                                {
                                    RFC_ET_SUB[i].circleDis = true;
                                    if(RFC_ET_SUB[i].stat == "S") RFC_ET_SUB[i].icon = "sap-icon://complete";
                                    else if(RFC_ET_SUB[i].stat == "H") RFC_ET_SUB[i].icon = "sap-icon://stop";
                                    else RFC_ET_SUB[i].circleDis = false;
                                }

                                oModel.setProperty("/app/pop_et_sub", RFC_ET_SUB);
                            }

                            var pop_save = this.byId("pop_save");
                            oModel.setProperty("/app/visibleTF", true);

                            if(pop_save != undefined && oModel.getProperty("/app/visibleTF") != "first")
                            {
                                if(POP_CLICK == "pop_detail")
                                {
                                    oModel.setProperty("/app/visibleTF", false);
                                }
                                else
                                {
                                    oModel.setProperty("/app/visibleTF", true);
                                }
                            }
                            else    //최초 실행시에만 undefined 
                            {
                                if(POP_CLICK == "pop_detail")
                                {
                                    oModel.setProperty("/app/visibleTF", false);
                                }
                                else
                                {
                                    oModel.setProperty("/app/visibleTF", true);
                                }
                            }

                            //화면세팅-end
                            oModel.setProperty("/app/pop_it_sub", pop_it_sub[0]);

                            this._pDialog.then(function(oDialog){
                                oDialog.open();
                            }.bind(this));
                        }

                        try
                        {
                            oModel.setProperty("/app/selectedKey", POP_CLICK);  //최초 실행시 에러 나기 때문에 이중으로 구현
                        }catch(e)
                        {
                            this.byId('iconTabBar').setSelectedKey(POP_CLICK);
                        }
                        
                        
                        
                    break;
                }
            },

            makeOdataFilter:function(oFilter) {
                var mFilter = [];
                
                for(var sKey in oFilter) {
                    var oVal = oFilter[sKey];
    
                    if(!(oVal instanceof Object) || oVal instanceof Date) {
                        if(oVal) {
                            mFilter.push(new sap.ui.model.Filter({
                                path: sKey,
                                operator: sap.ui.model.FilterOperator.EQ,
                                value1: oVal
                            }));
                        }
                    // Array로 입력된 Tokens값 처리
                    } else if(Array.isArray(oVal)) {
                        if(oVal.length > 0) {
                            for (var sArrayKey in oVal) {
                                var oFilterVal = oVal[sArrayKey];
        
                                mFilter.push(new sap.ui.model.Filter({
                                    path: sKey,
                                    operator: oFilterVal.operation,
                                    value1: oFilterVal.value1,
                                    value2: oFilterVal.value2
                                }));
                            }
                        }
                        
                     } else {
                        mFilter.push(new sap.ui.model.Filter({
                            path: sKey,
                            operator: sap.ui.model.FilterOperator.BT,
                            value1: oVal.value1,
                            value2: oVal.value2
                        }));
                    }
                }
    
                return mFilter;
            },

            //상세설명 팝업
            onRightDetailButton : function(oEvent)
            {
                var oButton = oEvent.getSource();
                var oView = this.getView();
                var oModel = this.getView().getModel();
                oModel.setProperty("/app/selectedKey", "pop_detail");
                oModel.setProperty("/app/click_title", POP_DET_TITLE+"신규 구독 생성");

                // oModel.setProperty("/app/selectedKey", "container-zotcur6500---Home--pop_detail");
                var that = this;
                var rowIdx = -1;
                var objTbl = ["et_ri", "et_ri_dtl", "et_var_field", "et_sub", "et_var_data"];
                var arr = [];

                if(oModel.getProperty("/app/risk_bizno").indexOf("BIZ") > -1)
                {
                    rowIdx = (""+oEvent.getSource().getBindingContext()).replace("/app/et_ri/", "");
                    arr = oModel.getProperty("/app/et_ri/"+rowIdx);
                }
                else if(oModel.getProperty("/app/risk_bizno") == "" || oModel.getProperty("/app/risk_bizno").indexOf("Main") > -1)
                {
                    rowIdx = (""+oEvent.getSource().getBindingContext()).replace("/app/et_my_ri/", "");
                    arr = oModel.getProperty("/app/et_my_ri/"+rowIdx);
                }
                else if(oModel.getProperty("/app/risk_bizno").indexOf("Search") > -1)
                {
                    rowIdx = (""+oEvent.getSource().getBindingContext()).replace("/app/et_list/", "");
                    arr = oModel.getProperty("/app/et_list/"+rowIdx);
                }

                oModel.setProperty("/app/my_ri", arr);
            
                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                oData.rino = arr.rino;
                //oData.subno = arr.subno;
                POP_CLICK = "pop_detail";
                that.getRfcData(that, oView, "Z_OTC_IF6503", objTbl, oData, false);
            },
           
            //편집/수정
            onRightUptButton : function(oEvent, ptable)
            {
                var oButton = oEvent.getSource();
                var oView = this.getView();
                var oModel = this.getView().getModel();
                //oModel.setProperty("/app/selectedKey", "pop_setting");
                

                var that = this;
                var use_rfc = (""+oEvent.getSource().getBindingContext()).split("/");

                var table = use_rfc[2];
               
                if(use_rfc.length ==2)
                {
                    //table = "et_list"
                    table = ptable;
                }
                var rowIdx = (""+oEvent.getSource().getBindingContext()).replace("/app/"+table+"/", "");
                if(use_rfc.length == 2)
                {
                    rowIdx = ""+oEvent.getParameters().rowIndex;
                }
                
                var objTbl = ["et_ri", "et_ri_dtl", "et_var_field", "et_sub", "et_var_data"];
                var arr = [];
                arr = oModel.getProperty("/app/"+table+"/"+rowIdx);

                oModel.setProperty("/app/my_ri", arr);
            
                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                oData.rino = arr.rino;
                oData.subno = arr.subno;
                POP_CLICK = "pop_setting";
                oModel.setProperty("/app/pop_subno", arr.subno);
                that.getRfcData(that, oView, "Z_OTC_IF6503", objTbl, oData, false);
            },

            onPopLeftCellClick : function(oControlEvent)
            {
                var rowIdx = ""+oControlEvent.getParameters().rowIndex;
                var oModel = this.getView().getModel();
                var DAT = oModel.getProperty("/app/pop_et_sub");
                POP_CLICK = "pop_setting";
   
                var that = this;
                var oView = this.getView();
                var objTbl = ["et_ri", "et_ri_dtl", "et_var_field", "et_sub", "et_var_data"];
            
                oModel.setProperty("/app/click_title", POP_DET_TITLE+DAT[rowIdx].subno);

                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                oData.rino = DAT[rowIdx].rino;
                oData.subno = DAT[rowIdx].subno;
                oModel.setProperty("/app/pop_subno", oData.subno);
                that.getRfcData(that, oView, "Z_OTC_IF6503", objTbl, oData, false);
            },

            onResetClick: function(oEvent)
            {
                var oButton = oEvent.getSource();
                var oView = this.getView();
                var oModel = this.getView().getModel();
                //oModel.setProperty("/app/selectedKey", "pop_detail");

                var that = this;
                var objTbl = ["et_ri", "et_ri_dtl", "et_var_field", "et_sub", "et_var_data"];

                oModel.setProperty("/app/click_title", POP_DET_TITLE+"신규 구독 생성");
  
                var rino = oModel.getProperty("/app/my_ri/rino");
                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                oData.rino = rino;
                oModel.setProperty("/app/pop_subno", "");

                that.getRfcData(that, oView, "Z_OTC_IF6503", objTbl, oData, false);
            },

            handlePopupClose: function (oEvent) 
            {
                var oModel = this.getView().getModel();
                oModel.setProperty("/app/pop_subno", '');

                var that = this;
                var oView = this.getView();
                var objTbl = ["et_my_ri"];
                if(oModel.getProperty("/app/risk_bizno") == "RiskItem")
                {
                    objTbl = ["et_ri"];
                }
            
                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                //var et_my_rp = [];
                //if(oModel.getProperty("/app/risk_bizno") == "RiskItem")
                //{
                //    oModel.getProperty("/app/et_rp");
                //}
                //else
                //{
                //    oModel.getProperty("/app/et_my_rp");
                //}
                //alert("RiskItem====>"+oModel.getProperty("/app/risk_bizno"));

                oData.rpno = oModel.getProperty("/app/click_rpno");
                oModel.setProperty("/app/click_title", POP_DET_TITLE);

                library.getRfcData(that, oView, "Z_OTC_IF6501", objTbl, oData, false);

                this.byId("riskitempopup_dialog").close();
            },

            onSave:function(oEvent)
            {
                var oModel = this.getView().getModel();
                var et_var_data = oModel.getProperty("/app/pop_et_var_data");
                var et_var_field = oModel.getProperty("/app/pop_et_var_field");
              
                var it_sub = [];
                it_sub[0] = oModel.getProperty("/app/pop_it_sub");

                if(it_sub[0].xmndty_tf)
                {
                    MessageBox.alert("필수 구독 항목은 수정불가능 합니다.");
                    return false;
                }

                if(it_sub[0].selectCol == 'zday')
                {
                    it_sub[0].zday = it_sub[0].selectKey;
                }
                else if(it_sub[0].selectCol == 'wknum')
                {
                    it_sub[0].wknum = it_sub[0].selectKey;
                }

                if(it_sub[0].xmndty_tf)
                {
                    it_sub[0].xmndty = "X";
                }
                else
                {
                    it_sub[0].xmndty = "";
                }

                if(it_sub[0].stat_tf)
                {
                    it_sub[0].stat = "H";
                }
                else
                {
                    it_sub[0].stat = "S";
                }
                

                var it_var_data = et_var_data;
                if(it_var_data.length == 0)
                {
                    it_var_data[i] = [{subno:'', fieldid:'', fielddata:''}];
                    for(var i=0; i<et_var_field.length; i++)
                    {
                        it_var_data[i] = [{subno:it_sub[0].subno, fieldid:et_var_field[i].fieldid, fielddata:''}];
                        it_var_data[i].subno=it_sub[0].subno;
                        it_var_data[i].fieldid=et_var_field[i].fieldid;
                        it_var_data[i].fielddata='';
                    }
                }

                for(var i=0; i<et_var_field.length; i++)
                {
                    var fieldid = et_var_field[i].fieldid;
                    
                    for(var j=0; j<it_var_data.length; j++)
                    {
                        if(it_var_data[j].fieldid == fieldid)
                        {
                            it_var_data[j].fielddata = et_var_field[i].fielddata;
                            break;
                        }
                    }

                    if(et_var_field[i].xmndty == "X")
                    {
                        if(et_var_field[i].fielddata == undefined || et_var_field[i].fielddata == '')
                        {
                            MessageBox.alert('"대상 data 범위"에 필수 조직정보를 입력해주세요');
                            return false;
                        }
                    }
                }

                var that = this;
                var oView = this.getView();
                var objTbl = ["et_ri", "et_ri_dtl", "et_var_field", "et_sub", "et_var_data", "it_sub", "it_var_data"];
                // Input Data 설정
                var oData = {};
                oData.ptype = "U";
                oData.subno = it_sub[0].subno;
                oData.rino = it_sub[0].rino;
                
                it_sub[0].logid = oModel.getProperty('/app/login').logid;
                oData.it_sub = it_sub;
                oData.it_var_data = it_var_data;

                //POP_CLICK = "pop_setting";
                that.getRfcData(that, oView, "Z_OTC_IF6503", objTbl, oData, false);
            },

            onFilterSelect: function(oEvent)
            {
                var sKey = oEvent.getParameter("key");
                var pop_save = this.byId("pop_save");
                pop_save.setProperty("visible", false);

                POP_CLICK = "pop_detail";
                if(sKey == "pop_setting")
                {
                    pop_save.setProperty("visible", true);
                    POP_CLICK = "pop_setting";
                }
            },

            onSearch: function(oEvent) 
            {
                var sUrl = '/sap/opu/odata/sap/ZOTC_EW_ODATA_SRV/';
                this.sDataModel = new sap.ui.model.odata.ODataModel(
                    sUrl, true
                );
                
                sap.ui.getCore().setModel(this.sDataModel);


                var sInputValue = oEvent.getSource().getValue();
                this.inputId = oEvent.getSource().getId();
                var path;
                var oTableStdListTemplate;
                var oFilterTableNo;
                this.oDialog = sap.ui.xmlfragment("zotcur6500.fragment.searchHelp", this);
                path = "/userSearchSet";
                oTableStdListTemplate = new sap.m.StandardListItem({title: "{Bname}",description: "{Responsible}"});// //create a filter for the binding
                oFilterTableNo = new sap.ui.model.Filter("Bname", sap.ui.model.FilterOperator.EQ, sInputValue);
                this.oDialog.unbindAggregation("items");
                this.oDialog.bindAggregation("items", {
                    path: path,
                    template: oTableStdListTemplate,
                    filters: [oFilterTableNo]}
                );// }// open value help dialog filtered by the input value
                this.oDialog.open(sInputValue);
            },

            onClearClick: function(oEvent) 
            {
                var oModel = this.getView().getModel();
                var str = ""+oEvent.getSource().getBindingContext();
                var rowIdx = str.replace("/app/pop_et_var_field/", "");

                var pop_et_var_field = [];
                pop_et_var_field = oModel.getProperty('/app/pop_et_var_field');
                pop_et_var_field[rowIdx].fielddata = ""; //초기화

                oModel.setProperty('/app/pop_et_var_field', pop_et_var_field);
            }
		});

	}
);