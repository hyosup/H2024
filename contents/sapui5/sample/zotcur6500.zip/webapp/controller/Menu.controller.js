sap.ui.define([
	"sap/ui/core/Core",
	"sap/ui/core/library",
    "control/library",
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
    "sap/ui/table/Column",
	"sap/m/Label",
	"sap/m/Text"
], 
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Core, CoreLibrary, library, Controller, ODataModel, MessageBox, MessageToast, Column, Label, Text) {
        "use strict";

        return Controller.extend("zotcur6500.controller.Menu", {
            onInit: function () {
                this.oOwnerComponent = this.getOwnerComponent();
                this.oRouter = this.oOwnerComponent.getRouter();
                this.oRouter.attachRouteMatched(this.onRouteMatched, this);
                this.oRouter.attachBeforeRouteMatched(this.onBeforeRouteMatched, this);
                
                //debugger;
                const router = this.getOwnerComponent().getRouter();
                router.navTo('Main');

                var that = this;
                var oView = this.getView();

                //var login = {appid:(""+oView.sViewName).split(".")[0], sapid:library.getUserID()};
                //var oModel = this.getView().getModel();
                //oModel.setProperty("/app/login", login);
                
                var objTbl = ["es_login", "et_vkgrp", "es_return"];
                // Input Data 설정
                var oData = {};
                library.getRfcData(that, oView, "Z_SWX_IF0001", objTbl, oData, false);
            },

            onBeforeRouteMatched: function(oEvent) {
                var oModel = this.oOwnerComponent.getModel(),
                	sLayout = oEvent.getParameters().arguments.layout,
                	oNextUIState;
            },

            onRouteMatched: function (oEvent) {
                var sRouteName = oEvent.getParameter("name"),
                    oArguments = oEvent.getParameter("arguments");

                // Save the current route name
                this.currentRouteName = sRouteName;
                this.currentProduct = oArguments.product;
            },

            workListFactory: function (sId, oContext) {
                var that = this;
                var oModel = this.getView().getModel();
                var sKey = oModel.getProperty(oContext.sPath).bizno;
                var sWorkNm = oModel.getProperty(oContext.sPath).biznm; 
    
                return new sap.m.IconTabFilter({
                    key: sKey,
                    text: sWorkNm 
                });
            },

            onHomePress: function (oEvent) {
                var oIconTabHeader = this.byId('iconTabHeader');
                oIconTabHeader.setSelectedKey('invalidKey');
                
                const router = this.getOwnerComponent().getRouter();
                var oModel = this.getView().getModel();
                oModel.setProperty('/app/risk_bizno', '');
                oModel.setProperty("/app/screenNm", "Home");

                var that = this;
                var oView = this.getView();
                
                var objTbl = ["et_my_sum", "et_my_rp", "et_my_ri"];
            
                // Input Data 설정
                var oData = {};
                oData.ptype = "R";
                oData.rpno = '';
                library.getRfcData(that, oView, "Z_OTC_IF6501", objTbl, oData, false);

                router.navTo('Main');
            },

            onSelectTab: function (event) {
                var oTab = event.getParameter('item');
                const router = this.getOwnerComponent().getRouter();
                var sKey = event.getParameters().selectedKey;
                var oModel = this.getView().getModel();
                var sView = '';
                var bizNo = "";
                switch (sKey) {
                    case 'MY':
                        //sView = 'My';
                        sView = "Main";
                        oModel.setProperty("/app/screenNm", "My");
                        break;             
                    case 'SEARCH':
                        sView = 'Search';
                        oModel.setProperty("/app/screenNm", "검색");
                        break;
                    case 'RiskItem':
                        sView = 'RiskItem';
                        oModel.setProperty("/app/screenNm", "항목제안");
                        break;                
                    default:
                        sView = 'Risk';
                        var Menu = oModel.getProperty('/app/worklist');
                        for(var i=0; i<Menu.length; i++)
                        {
                            if(sKey == Menu[i].bizno)
                            {
                                oModel.setProperty("/app/screenNm", Menu[i].biznm);
                            }
                        }
                        bizNo = sKey;
                }
                //debugger;

                if (sKey != '') 
                {
                    if(bizNo != "")
                    {
                        var that = this;
                        var oView = this.getView();
                        
                        var objTbl = ["et_rp", "et_ri"];
                        this.getView().getModel().setProperty('/app/risk_bizno', bizNo);
                        // Input Data 설정
                        var oData = {};
                        oData.ptype = "R";
                        oData.bizno = bizNo;
                        library.getRfcData(that, oView, "Z_OTC_IF6502", objTbl, oData, false);
                    }
                    else if(sKey=="MY")
                    {
                        var that = this;
                        var oView = this.getView();
                        
                        var objTbl = ["et_my_sum", "et_my_rp", "et_my_ri"];
                        this.getView().getModel().setProperty('/app/risk_bizno', 'Main');
                        // Input Data 설정
                        var oData = {};
                        oData.ptype = "R";
                        library.getRfcData(that, oView, "Z_OTC_IF6501", objTbl, oData, false);
                    }
                    else if(sKey=="RiskItem")
                    {
                        var that = this;
                        var oView = this.getView();
                        
                        var objTbl = ["et_list"];
                        this.getView().getModel().setProperty('/app/risk_bizno', sView);
                        // Input Data 설정
                        var oData = {};
                        oData.ptype = "R";
                        library.getRfcData(that, oView, "Z_OTC_IF6505", objTbl, oData, false);
                    }
                    else
                    {
                        this.getView().getModel().setProperty('/app/risk_bizno', sView);
                    }
                    
                    router.navTo(sView);
                }
            },

            onCallback: function(oModel, RFC_CD, ptype)
            {
                switch(RFC_CD)
                {
                    case "Z_SWX_IF0001":
                        oModel.setProperty("/app/riskItem_enabled", true);

                        var esReturn = oModel.getProperty("/app/es_return");
                        var mtype = esReturn.mtype;

                        var message = esReturn.message;
                        if(mtype == "E")
                        {
                            MessageBox.show(message, {
                                icon: MessageBox.Icon.ERROR,
                                title:"Error",
                                actions: [MessageBox.Action.OK]
                            });
                        }
                        else if(mtype == "W")
                        {
                            MessageBox.show(message, {
                                icon: MessageBox.Icon.WARNING,
                                title:"Warning",
                                actions: [MessageBox.Action.OK]
                            });
                        }


                        var sysip = oModel.getProperty("/app/sysip");
                        var login = oModel.getProperty("/app/es_login");
                        //login.sysip = oModel.getProperty("/app/ipAddress");
                        login.sysip = sysip[0];
                        login.appid = "zotcur6500";
                        oModel.setProperty("/app/login", login);

                        var vkgrp = oModel.getProperty("/app/et_vkgrp");
                        oModel.setProperty("/app/vkgrp", vkgrp);

                        var that = this;
                        var oView = this.getView();
                        
                        var objTbl = ["lt_biz"];
                    
                        // Input Data 설정
                        var oData = {};
                        oData.ptype = "R";
                        library.getRfcData(that, oView, "Z_OTC_IF6500", objTbl, oData, false);
                        break;
                    case "Z_OTC_IF6500":
                        var ET_BIZ = [];
                        ET_BIZ = oModel.getProperty("/app/lt_biz");

                        var MENU = [{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ,{bizno : "", biznm : ""}
                                    ];

                        MENU[0].bizno = "MY";
                        MENU[0].biznm = "MY";

                        MENU[1].bizno = "SEARCH";
                        MENU[1].biznm = "검색";
                        var cnt = 2;
                        for(var i=0; i < ET_BIZ.length; i++)
                        {
                            MENU[cnt].bizno = ET_BIZ[i].bizno;
                            MENU[cnt].biznm = ET_BIZ[i].biznm;
                            cnt++;
                        }

                        for(var i=ET_BIZ.length; i<7; i++)
                        {
                            MENU[cnt].bizno = "";
                            MENU[cnt].biznm = "";
                            cnt++;
                        }
                        MENU[cnt].bizno = "RiskItem";
                        MENU[cnt].biznm = "항목제안";


                        
                        // Return Data 바인딩 
                        oModel.setProperty('/app/worklist', MENU);
                        
                        ET_BIZ.push({bizno:'', biznm:''});

                        for(var i=ET_BIZ.length-1; i > 0; i--)
                        {
                            ET_BIZ[i].bizno = ET_BIZ[i-1].bizno;
                            ET_BIZ[i].biznm = ET_BIZ[i-1].biznm;
                        }
                        ET_BIZ[0].bizno = '';
                        ET_BIZ[0].biznm = '';
                        oModel.setProperty('/app/lt_biz_sel', ET_BIZ);

                        //첫 화면이라 호출
                        var that = this;
                        var oView = this.getView();
                        
                        var objTbl = ["et_my_sum", "et_my_rp", "et_my_ri"];
                    
                        // Input Data 설정
                        var oData = {};
                        oData.ptype = "R";
                        library.getRfcData(that, oView, "Z_OTC_IF6501", objTbl, oData, false);
                    break;
                    case "Z_OTC_IF6501":
                        library.fnSetHomeScr(oModel);
                        break;
                    case "Z_OTC_IF6502":
                        library.fnSetRiskTable(oModel);
                        break;
                    case "Z_OTC_IF6505":
                        library.fnSetRiskItem(oModel);
                        break;
                }
            },

            handleLoadItems: function(oControlEvent) {
                oControlEvent.getSource().getBinding("items").resume();
            }
        });
    });
