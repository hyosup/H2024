/*
*******************************************************************
1. Module(Sub) : c.ae
2. Parent Class : N/A
3. Implementation Class : c.ae.zcae000010f01.formatter
4. Description : Fixed Rate Allocation Factor formatter
*******************************************************************
                        Modification LOG
-------------------------------------------------------------------
No.    CSR/PJT No.    Date          Authors        Description
----   -----------    ----------    -----------    ----------------
001    LGE NEXT ERP   2023.07.05    ThienVHL       Create new
*******************************************************************
Comment:

    No.001 Create formatter for Fixed Rate Allocation Factor
*******************************************************************
*/
sap.ui.define([], function () {
    "use strict";
    return {
        /**
         * Format status icon function
         * @param {*} sStatus 
         * @returns status icon
        */
        formatStatusIcon: function (sStatus) {
            switch (sStatus) {
            case "New":
                return "sap-icon://add";
            case "Edit":
                return "sap-icon://accept";
            case "Delete":
                return "sap-icon://decline";
            default:
                return "";
            }
        },
        
        /**
         * Format status state function
         * @param {*} sStatus 
         * @returns status state
         */
        formatStatusState: function (sStatus) {
            switch (sStatus) {
            case "New":
                return "Success";
            case "Edit":
                return "Information";
            case "Delete":
                return "Error";
            default:
                return "None";
            }
        },

        /**
         * Format number to display on screen
         * @param {*} nNumber 
         * @returns - Number with format
         */
        formatNumber: function (nNumber) {
            let nValueFormat = 0;
            
            if(nNumber) {
                nValueFormat = nNumber;
            }
            return parseFloat(nValueFormat).toFixed(1);
        }
    };
});