/* global QUnit */

sap.ui.require(["ycae000010f01/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
