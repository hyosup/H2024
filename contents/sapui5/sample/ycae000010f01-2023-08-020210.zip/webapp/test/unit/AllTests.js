sap.ui.define([
	"ycae000010f01/test/unit/controller/App.controller"
], function () {
	"use strict";
});
