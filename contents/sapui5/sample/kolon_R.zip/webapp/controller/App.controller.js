sap.ui.define(
  [
    'sap/ui/core/mvc/Controller', //
    'sap/m/MessageBox',
    'sap/ui/core/Fragment',
    'sap/ui/core/format/DateFormat',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
  ],
  function (
    Controller,
    MessageBox,
    Fragment,
    DateFormat,
    Filter,
    FilterOperator
  ) {
    'use strict';
    return Controller.extend('sap.ui.demo.walkthrough.controller.App', {
      pDetailDialog: null,

      onInit() {
        const oView = this.getView();
        const oModelR = sap.ui.getCore().getModel('ROOT');
        oModelR.setProperty('/', {
          Currency: 'USD',
          sample: {
            Begda: new Date('2022-10-03'),
            Endda: new Date('2023-09-20'),
            listInfo: { rowCount: 2 },
            list: [
              {
                datum: new Date('2023-06-22 15:46:00:000'),
                checkval: '',
                typeval: 'Payroll deduction',
                locationval: 'Office(for payroll deduction)',
                amountval: '52.36',
              },
              {
                datum: new Date('2023-06-22 15:04:00:000'),
                checkval: '262',
                typeval: 'Sale',
                locationval: 'GA',
                amountval: '52.36',
              },
            ],
            badge: '12345678',
            chargesn: '1',
            chargest: '52.36',
            paymentsn: '1',
            paymentst: '-52.36',
            datums: new Date('2022-10-03'),
            datume: new Date('2023-09-20'),
            balance: '104.72',
          },
          // 경조 기본정보
          form: {
            Concode: '', // 유형
            Conresn: '', // 사유
            Kdsvh: '', // 관계
            Zeloc: '', // 장소
            Zbirthday: null, // 생년월일
            Conddate: null, // 경조일
          },
          // 관계 목록
          list: [
            {
              Idx: 1,
              Relation: '10',
              Ename: '김수현',
              Birth: new Date('1985-03-15'),
            }, //
            {
              Idx: 2,
              Relation: '14',
              Ename: '박서준',
              Birth: new Date('2008-02-10'),
            },
            {
              Idx: 3,
              Relation: '16',
              Ename: '박은빈',
              Birth: new Date('2010-11-02'),
            },
          ],
          listInfo: {
            rowCount: 3,
            totalCount: 3,
            selectionMode: 'MultiToggle',
          },
          detail: {}, // 보기 팝업
          entry: {
            // 유형 엔트리
            Concode: [
              { Zcode: '1000', Ztext: '결혼' },
              { Zcode: '2000', Ztext: '회갑' },
              { Zcode: '4000', Ztext: '사망' },
              { Zcode: '5000', Ztext: '상해입원' },
            ],
            // 사유 엔트리
            Conresn: [],
            // 관계 엔트리
            Kdsvh: [],
          },
          ConresnList: [
            { Concode: '1000', Zcode: '1010', Ztext: '본인결혼' },
            { Concode: '1000', Zcode: '1020', Ztext: '자녀 결혼' },
            { Concode: '1000', Zcode: '1030', Ztext: '형제자매 결혼' },
            { Concode: '1000', Zcode: '1040', Ztext: '배우자의 형제자매 결혼' },
            { Concode: '2000', Zcode: '2010', Ztext: '본인 회갑' },
            { Concode: '2000', Zcode: '2020', Ztext: '배우자 회갑' },
            { Concode: '2000', Zcode: '2030', Ztext: '부모 회갑' },
            { Concode: '2000', Zcode: '2040', Ztext: '배우자의 부모 회갑' },
            { Concode: '2000', Zcode: '2050', Ztext: '조부모 회갑' },
            { Concode: '4000', Zcode: '4020', Ztext: '부모 사망' },
            { Concode: '4000', Zcode: '4030', Ztext: '배우자 사망' },
            { Concode: '4000', Zcode: '4040', Ztext: '자녀 사망' },
            { Concode: '4000', Zcode: '4050', Ztext: '배우자의 부모 사망' },
            { Concode: '4000', Zcode: '4060', Ztext: '형제자매 사망' },
            { Concode: '4000', Zcode: '4070', Ztext: '조부모,외조부모 사망' },
            { Concode: '4000', Zcode: '4080', Ztext: '배우자의 형제자매 사망' },
            {
              Concode: '4000',
              Zcode: '4090',
              Ztext: '백부/백모/숙부/숙모 사망',
            },
            { Concode: '5000', Zcode: '5010', Ztext: '2주이상~4주미만' },
            { Concode: '5000', Zcode: '5020', Ztext: '4주이상~6주미만' },
            { Concode: '5000', Zcode: '5030', Ztext: '6주이상~8주미만' },
            { Concode: '5000', Zcode: '5040', Ztext: '8주이상' },
          ],
          KdsvhList: [
            {
              Conresn: ['1010', '2010', '5010', '5020', '5030', '5040'],
              Zcode: 'ME',
              Ztext: '본인',
            },
            { Conresn: ['1020', '4040'], Zcode: '14', Ztext: '아들' },
            { Conresn: ['1020', '4040'], Zcode: '16', Ztext: '딸' },
            { Conresn: ['1030', '4060'], Zcode: '30', Ztext: '형(오빠)' },
            { Conresn: ['1030', '4060'], Zcode: '32', Ztext: '제(남동생)' },
            { Conresn: ['1030', '4060'], Zcode: '34', Ztext: '자(누나,언니)' },
            { Conresn: ['1030', '4060'], Zcode: '36', Ztext: '매(여동생)' },
            {
              Conresn: ['1040', '4060', '4080'],
              Zcode: '48',
              Ztext: '배우자의 형제',
            },
            {
              Conresn: ['1040', '4060', '4080'],
              Zcode: '50',
              Ztext: '배우자의 자매',
            },
            { Conresn: ['2020', '4030'], Zcode: '10', Ztext: '처' },
            { Conresn: ['2020', '4030'], Zcode: '12', Ztext: '남편' },
            { Conresn: ['2030', '4020'], Zcode: '22', Ztext: '부' },
            { Conresn: ['2030', '4020'], Zcode: '24', Ztext: '모' },
            { Conresn: ['2040', '4050'], Zcode: '26', Ztext: '배우자의 부' },
            { Conresn: ['2040', '4050'], Zcode: '28', Ztext: '배우자의 모' },
            { Conresn: ['2050', '4070'], Zcode: '52', Ztext: '조부' },
            { Conresn: ['2050', '4070'], Zcode: '54', Ztext: '조모' },
            { Conresn: ['4070'], Zcode: '60', Ztext: '외조부' },
            { Conresn: ['4070'], Zcode: '62', Ztext: '외조모' },
            { Conresn: ['4090'], Zcode: '76', Ztext: '백부' },
            { Conresn: ['4090'], Zcode: '78', Ztext: '백모' },
            { Conresn: ['4090'], Zcode: '80', Ztext: '숙부' },
            { Conresn: ['4090'], Zcode: '82', Ztext: '숙모' },
          ],
        });
        oView.setModel(oModelR);
        oView.bindObject({ path: '/' });
      },

      /**
       * 조회 실행
       * @param {*} oEvent
       */
      onSearch: function (oEvent) {
        const oView = this.getView();
        const oContext = oView.getBindingContext();

        let oFilter = {
          Begda: DateFormat.getDateInstance({ pattern: 'yyyyMMdd' }).format(
            oContext.getProperty('/sample/Begda') //.toISOString().slice(0, 10)
          ),
          Endda: DateFormat.getDateInstance({ pattern: 'yyyyMMdd' }).format(
            oContext.getProperty('/sample/Endda')
          ),
        };

        let aFilter = [
          new Filter({
            path: 'input',
            operator: FilterOperator.BT,
            value1:
              typeof oFilter === 'string' ? oFilter : JSON.stringify(oFilter),
          }),
        ];

        oView.setBusy(true);

        /* oData Service Model 호출 */
        const oModelO = sap.ui.getCore().getModel('ODAT');
        /* Call GET_ENTITYSET with Filters */
        oModelO.read('/SAMPLE01Set', {
          async: false,
          filters: aFilter,
          success: oRespData => {
            //let aData = oRespData.results;
            let aData = JSON.parse(oRespData.results[0].output);
            let oModelV = oView.getModel();
            let oContext = oView.getBindingContext();

            aData.list.forEach(obj => {
              const dateToCheck = ['datum'];
              dateToCheck.forEach(key => {
                if (
                  obj.hasOwnProperty(key) &&
                  new Date(obj[key]).toString() !== 'Invalid Date'
                ) {
                  obj[key] = new Date(obj[key]);
                }
              });
            });

            let sampleData = oModelV.getProperty(oContext.getPath() + 'sample');
            oModelV.setProperty(oContext.getPath() + 'sample', {
              ...sampleData,
              list: aData.list,
              badge: aData.badge,
              chargesn: aData.chargesn,
              chargest: aData.chargest,
              paymentsn: aData.paymentsn,
              paymentst: aData.paymentst,
              datums: new Date(aData.datums),
              datume: new Date(aData.datume),
              balance: aData.balance,
            });

            oView.setBusy(false);
          },
          error: oError => {
            oView.setBusy(false);
          },
        });
      },

      /**
       * 언어 ComboBox 이벤트핸들러
       *
       * @param {sap.ui.base.Event} oEvent
       */
      onChangeLanguage(oEvent) {
        const sSelectedKey = oEvent.getSource().getSelectedKey();

        sap.ui.getCore().getConfiguration().setLanguage(sSelectedKey);
      },

      /**
       * 유형 ComboBox 이벤트핸들러
       *	- 사유 ComboBox 엔트리를 변경
       *
       * @param {sap.ui.base.Event} oEvent
       */
      onChangeConcode: function (oEvent) {
        const oViewModel = this.getView().getModel();
        const aConresnList = oViewModel.getProperty('/ConresnList'); // 사유 전체목록
        const sSelectedKey = oEvent.getSource().getSelectedKey(); // 1000
        const aSelectedCoresn = aConresnList.filter(
          el => el.Concode === sSelectedKey
        );

        oViewModel.setProperty('/entry/Conresn', aSelectedCoresn);
        oViewModel.setProperty('/form/Conresn', '');
        oViewModel.setProperty('/form/Kdsvh', '');
      },

      /**
       * 사유 ComboBox 이벤트핸들러
       *	- 관계 ComboBox 엔트리를 변경
       *
       * @param {sap.ui.base.Event} oEvent
       */
      onChangeConresn: function (oEvent) {
        const oViewModel = this.getView().getModel();
        const aKdsvhList = oViewModel.getProperty('/KdsvhList');
        const sSelectedKey = oEvent.getSource().getSelectedKey();
        const aSelectedKdsvh = aKdsvhList.filter(el =>
          el.Conresn.includes(sSelectedKey)
        );

        oViewModel.setProperty('/entry/Kdsvh', aSelectedKdsvh);
        oViewModel.setProperty('/form/Kdsvh', '');
      },

      /**
       * (Async) 목록-보기 Button 이벤트핸들러
       *	- 상세내역 팝업을 호출
       *
       * @param {sap.ui.base.Event} oEvent
       */
      onPressDetail: async function (oEvent) {
        const oViewModel = this.getView().getModel();
        const mSelectedRowData = oEvent
          .getSource()
          .getParent()
          .getParent()
          .getBindingContext()
          .getObject();

        oViewModel.setProperty('/detail', { ...mSelectedRowData });

        if (!this.pDetailDialog) {
          const oView = this.getView();
          this.pDetailDialog = await Fragment.load({
            id: oView.getId(),
            name: 'sap.ui.demo.walkthrough.view.fragment.DetailDialog',
            controller: this,
          });
          oView.addDependent(this.pDetailDialog);
        }

        this.pDetailDialog.open();
      },

      /**
       * 상세내역 팝업을-닫기 Button 이벤트핸들러
       *
       */
      onPressCloseDialog: function () {
        this.pDetailDialog.close();
      },

      /**
       * 목록-추가 Button 이벤트핸들러
       *
       */
      onPressAdd: function () {
        const oViewModel = this.getView().getModel();
        const aList = oViewModel.getProperty('/list');
        const iNestIdx = aList[aList.length - 1]?.Idx + 1 || 1;

        oViewModel.setProperty('/list', [...aList, { Idx: iNestIdx }]);
        oViewModel.setProperty('/listInfo/totalCount', aList.length + 1);
        oViewModel.setProperty(
          '/listInfo/rowCount',
          Math.min(aList.length + 1, 10)
        );
      },

      /**
       * 목록-삭제 Button 이벤트핸들러
       *
       */
      onPressLess: function () {
        const oViewModel = this.getView().getModel();
        const oBundle = this.getView().getModel('i18n').getResourceBundle();
        const oTable = this.byId('relationTable');
        const aSelectedIndices = oTable.getSelectedIndices(); // 선택한 table row index 배열

        if (aSelectedIndices.length < 1) {
          MessageBox.alert(oBundle.getText('messageRequireDeleteTarget')); // 삭제할 대상을 선택하여 주십시오.
          return;
        }

        const sConfirmMessage = oBundle.getText('messageDeleteConfirm');
        MessageBox.confirm(sConfirmMessage, {
          actions: [oBundle.getText('delete'), MessageBox.Action.CANCEL],
          onClose: function (sAction) {
            if (sAction === MessageBox.Action.CANCEL) return;

            const aTableData = oViewModel.getProperty('/list');
            const oTableRows = oTable.getBinding('rows');
            const aSelectedRows = oTableRows
              .getContexts(0, oTableRows.getLength())
              .filter((el, idx) => aSelectedIndices.includes(idx))
              .map(el => el.getObject());
            const aUnSelectedData = aTableData.filter(el => {
              return !aSelectedRows.some(d => el.Idx === d.Idx);
            });

            oViewModel.setProperty(
              '/listInfo/totalCount',
              aUnSelectedData.length
            );
            oViewModel.setProperty(
              '/listInfo/rowCount',
              Math.min(aUnSelectedData.length, 10)
            );
            oViewModel.setProperty(
              '/list',
              aUnSelectedData.map((el, idx) => ({ ...el, Idx: idx + 1 }))
            );
          },
        });
      },
    });
  }
);
