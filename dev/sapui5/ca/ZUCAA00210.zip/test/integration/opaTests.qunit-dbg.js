/* global QUnit */

sap.ui.require(["hkmc/ca/zucaa00210/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
