sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    function (BaseController) {
        "use strict";

        return BaseController.extend("hkmc.ca.zucaa00210.controller.App", {
        });
    });
