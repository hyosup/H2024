sap.ui.define([
    "hkmc/ca/zucaa00210/controller/BaseController",
    "hkmc/ca/zucaa00210/model/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "hkmc/ca/zucaa00210/utils/Confirm"
], function (Controller, formatter, JSONModel, Fragment, MessageBox, MessageToast, Confirm) {
    "use strict";

    return Controller.extend("hkmc.ca.zucaa00210.controller.List", {
        formatter: formatter,
        onInit: function () {
            this.getModel().attachRequestSent(function () {
                this.getView().setBusy(true);
            }.bind(this));
            this.getModel().attachRequestCompleted(function () {
                this.getView().setBusy(false);
            }.bind(this));

            this.getRoute("RouteList").attachPatternMatched(this._onObjectTreeListMatched, this);

            this._oList = this.byId("idTree");
            this._addTreeContextMenu();

            var oConfig = new JSONModel({
                isRoot: true
            });
            this.getView().setModel(oConfig, "viewConfig");
            this._oList = this.byId("idTree");
            this._aSelectedIndices = [];
        },
        _onObjectTreeListMatched: function (oEvent) {
            this._bindTree();
        },
        _bindTree: function () {
            var oTree = this.byId("idTree");
            oTree.bindItems({
                path: "/TreeSet",
                mode: "SingleSelectMaster",
                parameters: {
                    countMode: "Inline",
                    numberOfExpandedLevels: 5
                },
                template: new sap.m.StandardTreeItem({
                    title: "{Title} : {Zdesc}",
                    tooltip: {
                        path: "NodeType",
                        formatter: this.formatter.formatTreeTooltip
                    },
                    icon: {
                        parts: [{
                            path: "NodeType"
                        }, {
                            path: "Zdel"
                        }],
                        formatter: this.formatter.formatTreeIcon
                    }
                })

            });
        },
        _expandTree: function () {
            var oTreeItems = this._oList.getItems();
            var oModel = this.getView().getModel();
            this._aSelectedIndices = [];
            for (var i = 0; i < oTreeItems.length; i++) {
                if (oTreeItems[i].getExpanded()) {
                    var oItem = oModel.getProperty(oTreeItems[i].getBindingContext().getPath());
                    this._aSelectedIndices.push(oItem.NodeId);
                }
            }
        },
        onUpdateFinished: function (oEvent) {
            var oTreeItems = this._oList.getItems();
            var oModel = this.getView().getModel();
            for (var i = 0; i < oTreeItems.length; i++) {
                var oItem = oModel.getProperty(oTreeItems[i].getBindingContext().getPath());
                if (this._aSelectedIndices[0] === oItem.NodeId) {
                    this._aSelectedIndices.splice(0, 1);
                    if (!oTreeItems[i].isLeaf()) {
                        this._oList.expand(this._oList.indexOfItem(oTreeItems[i]));
                    }
                    break;
                }
            }
        },
        _addTreeContextMenu: function () {
            var oResourceBundle = this.getResourceBundle();

            this._oList.setContextMenu(new sap.m.Menu({
                items: [
                    new sap.m.MenuItem({
                        text: oResourceBundle.getText("createNode"),
                        icon: "sap-icon://create",
                        press: this.handleNodeCreatePress.bind(this)
                    }),
                    new sap.m.MenuItem({
                        text: oResourceBundle.getText("editNode"),
                        icon: "sap-icon://edit",
                        press: this.handleNodeEditPress.bind(this)
                    }),
                    new sap.m.MenuItem({
                        text: oResourceBundle.getText("deleteNode"),
                        icon: "sap-icon://delete",
                        press: this.handleNodeDeletePress.bind(this)
                    }),
                    new sap.m.MenuItem({
                        text: oResourceBundle.getText("recoverNode"),
                        icon: "sap-icon://undo",
                        press: this.handleNodeRecoverPress.bind(this)
                    })
                ]
            }));
        },
        onBeforeOpenContextMenu: function (oEvent) {
            var oItem = this.getViewModel().getProperty(oEvent.getParameter("listItem").getBindingContextPath());
            var oContextMenuItems = oEvent.getSource().getContextMenu().getItems();
                //삭제 표시 true인 노드는 delete, recover 메뉴만 보이게 설정
                oContextMenuItems[0].setVisible(!oItem.Zdel);
                oContextMenuItems[1].setVisible(!oItem.Zdel);
                oContextMenuItems[3].setVisible(oItem.Zdel);
                // leaf 노드는 create 메뉴가 보이지 않게 설정
                if (oItem.NodeType === "leaf" || oItem.Zdel === true) {
                    oContextMenuItems[0].setVisible(false);
                } else {
                    oContextMenuItems[0].setVisible(true);
                }
        },
        onDragStart: function (oEvent) {
            var oDragSession = oEvent.getParameter("dragSession");
            var oDraggedItem = oEvent.getParameter("target");
            oDragSession.setComplexData("hierarchymaintenance", {
                draggedItemContexts: oDraggedItem
            });
        },
        onDrop: function (oEvent) {
            var oTree = this.byId("idTree"),
                oBinding = oTree.getBinding("items"),
                oDragSession = oEvent.getParameter("dragSession"),
                oDroppedItem = oEvent.getParameter("droppedControl"),
                aDraggedItemContexts = oDragSession.getComplexData("hierarchymaintenance").draggedItemContexts,
                iDroppedIndex = oTree.indexOfItem(oDroppedItem),
                oNewParentContext = oBinding.getContextByIndex(iDroppedIndex),
                oOption = oEvent.getParameter("dropPosition"),
                oModel = this.getViewModel(),
                oDraggedItemData = oModel.getProperty(aDraggedItemContexts.getBindingContextPath()),
                oDroppedItemData = oModel.getProperty(oDroppedItem.getBindingContextPath());

            if (aDraggedItemContexts.length === 0 || !oNewParentContext) {
                return;
            }
            if (oDraggedItemData.NodeId === oDroppedItemData.NodeId) {
                return;
            }
            if (oDraggedItemData.NodeId === oDroppedItemData.PnodeId) {
                return;
            }
            if (oOption === "On" && oDroppedItemData.NodeType !== "expanded") {
                return;
            }
            var oParentNode = oDroppedItem.getParentNode(),
                oParentNodeData;
            while (oParentNodeData !== undefined) {
                oParentNodeData = oModel.getProperty(oParentNode.getBindingContextPath());
                if (oDraggedItemData.NodeId === oParentNodeData.NodeId) {
                    return;
                }
                oParentNode = oParentNode.getParentNode();
            }
            oDraggedItemData.PnodeId = oDroppedItemData.NodeId; //"pnode_id를 target_node_id로 전용하여 전달
            switch (oOption) {
                case "On":
                    oDraggedItemData.NodeState = "MOVEON";
                    break;
                case "Before":
                    oDraggedItemData.NodeState = "MOVEBEFORE";
                    break;
                case "After":
                    oDraggedItemData.NodeState = "MOVEAFTER";
                    break;
            }
            var sPath = oModel.createKey("/TreeSet", {
                NodeId: oDraggedItemData.NodeId
            });
            oModel.update(sPath, oDraggedItemData, {
                success: function (oData, oResponse) {

                }.bind(this),
                error: function (oError) {
                    return;
                }
            });

        },
        handleRootCreatePress: function (oEvent) {

            this.getView().getModel("viewConfig").setProperty("/isRoot", true);
            var oModel = this.getView().getModel();
            oModel.metadataLoaded().then(function () {
                var oContext = oModel.createEntry("TreeSet", null);
                this.getView().bindElement({
                    path: oContext.getPath()
                });

                if (!this.pDialog) {
                    this.pDialog = this.loadFragment({
                        name: "hkmc.ca.zucaa00210.view.fragment.CreateDialog",
                        controller: this
                    });
                }
                this.pDialog.then(function (oDialog) {
                    oDialog.open();
                    oDialog.bindElement(oContext.getPath());
                }.bind(this));

            }.bind(this));
        },
        handleNodeCreatePress: function (oEvent) {
            this._createPnodId = oEvent.getSource().getParent().getBindingContext().getObject().NodeId;
            this.getView().getModel("viewConfig").setProperty("/isRoot", false);
            var oModel = this.getView().getModel();

            oModel.metadataLoaded().then(function () {
                var oContext = oModel.createEntry("TreeSet", null);

                if (!this.pDialog) {
                    this.pDialog = this.loadFragment({
                        name: "hkmc.ca.zucaa00210.view.fragment.CreateDialog",
                        controller: this
                    });

                }
                this.pDialog.then(function (oDialog) {
                    oDialog.open();
                    oModel.setProperty(oContext.getPath() + "/NodeType", "expanded");
                    oModel.setProperty(oContext.getPath() + "/LineInStatus", "Success");
                    oDialog.bindElement(oContext.getPath());

                }.bind(this));
            }.bind(this));
        },

        handleNodeEditPress: function (oEvent) {
            this._sEditPath = oEvent.getSource().getParent().getBindingContext().getPath();

            if (!this.pDialogEdit) {
                this.pDialogEdit = this.loadFragment({
                    name: "hkmc.ca.zucaa00210.view.fragment.EditDialog",
                    controller: this
                });
            }
            this.pDialogEdit.then(function (oDialog) {
                oDialog.open();
                oDialog.bindElement(this._sEditPath);
            }.bind(this));


        },
        handleNodeDeletePress: function (oEvent) {
            this._oSelected = oEvent.getSource().getBindingContext();
            var oModel = this.getView().getModel(),
                oResourceBundle = this.getResourceBundle(),
                sPath = this._oSelected.getPath();

            MessageBox.confirm(oResourceBundle.getText("deleteMessage"), {
                title: oResourceBundle.getText("deleteTitle"),
                styleClass: "",
                actions: [sap.m.MessageBox.Action.OK,
                sap.m.MessageBox.Action.CANCEL],
                emphasizedAction: sap.m.MessageBox.Action.OK,
                onClose: function (sAction) {
                    if (sAction === "OK") {
                        oModel.remove(sPath, {
                            success: function (oData, oResponse) {
                                MessageToast.show(oResourceBundle.getText("deleteSuccessfully"));
                            },
                            error: function (oError) {
                                MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                            }
                        });
                    }
                }
            });
            this._expandTree();

        },
        handleNodeRecoverPress: function (oEvent) {
            this._oSelected = oEvent.getSource().getBindingContext();
            var oConfirm = new Confirm({
                handleSubmit: this._confirmRecover.bind(this)
            });
            oConfirm.show();
            this._expandTree();
        },
        _confirmRecover: function () {
            var oModel = this.getViewModel(),
                oResourceBundle = this.getResourceBundle();
            var oEntity = oModel.getProperty(this._oSelected.getPath());
            oEntity.NodeState = "RECOVER";
            oModel.update(this._oSelected.getPath(), oEntity, {
                success: function (oData, oResponse) {
                    MessageToast.show(oResourceBundle.getText("saveSuccessfully"));
                },
                error: function (oError) {
                    MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                }
            });
        },
        handleDialogCancelPress: function (oEvent) {
            var oDialog = oEvent.getSource().getParent();

            var oModel = this.getView().getModel();
            if (oModel.hasPendingChanges()) {
                oModel.resetChanges();
            }

            oDialog.close();
            this._createPnodId = "";
        },
        handleEditSavePress: function (oEvent) {
            var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle(),
                oModel = this.getView().getModel(),
                oDialog = oEvent.getSource().getParent(),
                oItem = this.byId("idEditDialog").getBindingContext().getObject();

            oItem.NodeState = "EDIT";

            if (oItem.NodeType === "expanded") {
                oItem.ObjId = "";
            }

            var oUpdatedData = {
                Title: oItem.Title,
                Zdesc: oItem.Zdesc,
                NodeType: oItem.NodeType,
                LineInStatus: oItem.LineInStatus,
                ObjId: oItem.ObjId,
                NodeState: oItem.NodeState
            };

            oModel.update(this._sEditPath, oUpdatedData, {
                success: function (oData, oResp) {
                    sap.m.MessageToast.show(oResourceBundle.getText("msgSaveSuccessfully"));
                    oDialog.close();
                }.bind(this),
                error: function (oError) {
                    if (oError.statusCode === 500) {
                        MessageToast.show(oResourceBundle.getText("msgUpdateError"));
                    } else {
                        MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                    }
                }
            });

            this._expandTree();
        },
        handleCreateSavePress: function (oEvent) {
            var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle(),
                oModel = this.getView().getModel();

            var oDialog = oEvent.getSource().getParent(),
                oItem = this.byId("idCreateDialog").getBindingContext().getObject();

            var oCreatedData = {
                PnodeId: this._createPnodId,
                Title: oItem.Title,
                Zdesc: oItem.Zdesc,
                NodeType: oItem.NodeType,
                ObjId: oItem.ObjId,
                LineInStatus: oItem.LineInStatus
            };

            oModel.create('/TreeSet', oCreatedData, {
                success: function (oData, oResp) {
                    sap.m.MessageToast.show(oResourceBundle.getText("msgSaveSuccessfully"));
                    oDialog.close();
                    this._createPnodId = "";
                }.bind(this),
                error: function (oError) {
                    if (oError.statusCode === 500) {
                        MessageToast.show(oResourceBundle.getText("msgUpdateError"));
                    } else {
                        MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                    }
                }
            });
            this._expandTree();
        }
    });
});