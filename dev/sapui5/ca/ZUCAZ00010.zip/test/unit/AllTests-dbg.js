sap.ui.define([
	"hkmcca/zucaz00010/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
