sap.ui.define([
	"hkmc/ca/zucaz00030/test/unit/controller/List.controller"
], function () {
	"use strict";
});
